package com.nichi.sharing;

import java.util.List;

import com.nichi.database.DataBaseManager;
import com.nichi.model.BhavCopyData;
import com.nichi.model.TableRowData;
import com.nichi.model.User;

import javafx.application.HostServices;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class Share {

    private static void shareHelper(Stage primaryStage, BorderPane root, Scene scene, MenuBar menuBar, HostServices hostServices,
                                    VBox menuAndButtons, ObservableList<User> friendList, Object data,String symbol) {
        scene.getStylesheets().add(Share.class.getResource("/com/nichi/application/application.css").toExternalForm());

        root.setTop(menuAndButtons);
        root.setCenter(null);
        root.setRight(null);
        root.setBottom(null);

        Label friendLabel = new Label("Friends:");
        ComboBox<User> friendComboBox = new ComboBox<>(friendList);
        friendComboBox.setPromptText("Select a friend");

        friendComboBox.setCellFactory(param -> {
            ListCell<User> cell = new ListCell<>() {
                @Override
                protected void updateItem(User user, boolean empty) {
                    super.updateItem(user, empty);

                    if (empty || user == null) {
                        setText(null);
                    } else {
                        setText(user.getUsername());
                    }
                }
            };
            return cell;
        });

        Label message = new Label("Message");
        TextField messageField = new TextField();
        messageField.setText("The Overview of *"+symbol+"* is: "+data.toString());
        messageField.setEditable(false);
        
        CheckBox topGainersLosersCheckBox = new CheckBox("Share Top 5 gainers and losers, Volume Gainers");
        

        Button shareButton = new Button("Share via WhatsApp");

        Label statusLabel = new Label();

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        grid.add(friendLabel, 0, 0);
        grid.add(friendComboBox, 1, 0);
        grid.add(message, 0, 2);
        grid.add(messageField, 1, 2);
        grid.add(topGainersLosersCheckBox, 0, 3);
        grid.add(shareButton, 0, 4);
        grid.add(statusLabel, 0, 5);
        
        topGainersLosersCheckBox.setOnAction(e->{
        	if(topGainersLosersCheckBox.isSelected()) {
        		System.out.println("Checkbox is clicked.");
        	}
        	else {
        		System.out.println("Check Box is not selected");
        	}
        	
        });


        
     // Prepare a StringBuilder to construct the message
        StringBuilder messageBuilder = new StringBuilder();
        messageBuilder.append(" *Top Gainers are:* ");
        // Append top gainers
        List<BhavCopyData> gainerData = DataBaseManager.gainer_data;
        for (int i = 0; i < Math.min(5, gainerData.size()); i++) {
            messageBuilder.append("\n"+gainerData.get(i).getSymbol());
            if (i < Math.min(5, gainerData.size()) - 1) {
                messageBuilder.append(", ");
            }
        }
        messageBuilder.append("\n");
        messageBuilder.append(" *Top Losers are:* ");
        // Append top losers
        List<BhavCopyData> loserData = DataBaseManager.looser_data;
        for (int i = 0; i < Math.min(5, loserData.size()); i++) {
            messageBuilder.append(loserData.get(i).getSymbol());
            if (i < Math.min(5, loserData.size()) - 1) {
                messageBuilder.append(", ");
            }
        }
        
        messageBuilder.append("\n");
        messageBuilder.append(" *Volume Gainers are:* ");
        // Append top losers
        List<TableRowData> volumeData = DataBaseManager.volumeGainer_data;
        for (int i = 0; i < Math.min(5, volumeData.size()); i++) {
            messageBuilder.append(volumeData.get(i).getSymbol());
            if (i < Math.min(5, volumeData.size()) - 1) {
                messageBuilder.append(", ");
            }
        }
        
        shareButton.setOnAction(event -> {
            System.out.println("Clicked on WhatsApp.");
            try {
            String number = friendComboBox.getValue().getPhoneNumber();
            System.out.println(number);
            String whatsappMessage = messageField.getText();

            if (isValidPhoneNumber(number)) {
                if (topGainersLosersCheckBox.isSelected()) {
                	whatsappMessage += messageBuilder.toString();

                }
                String whatsappUrl = "https://api.whatsapp.com/send?phone=+91" + number + "&text=" + whatsappMessage;
                hostServices.showDocument(whatsappUrl);
                statusLabel.setText("WhatsApp opened with pre-filled message.");
            } else {
                statusLabel.setText("Invalid phone number.");
            }
            }catch(Exception e) {
            	System.out.println("Please select friend to send...");
            	statusLabel.setText("Please select a friend to send	");
            }
        });


        root.setCenter(grid);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void share(Stage primaryStage, BorderPane root, Scene scene, MenuBar menuBar, HostServices hostServices,
                             BhavCopyData data, VBox menuAndButtons, ObservableList<User> friendList) {
        shareHelper(primaryStage, root, scene, menuBar, hostServices, menuAndButtons, friendList, data,data.getSymbol());
    }

    public static void share(Stage primaryStage, BorderPane root, Scene scene, MenuBar menuBar, HostServices hostServices,
                             TableRowData data, VBox menuAndButtons, ObservableList<User> friendList) {
        shareHelper(primaryStage, root, scene, menuBar, hostServices, menuAndButtons, friendList, data,data.getSymbol());
    }
    public static boolean isValidPhoneNumber(String phoneNumber) {
        // Remove any whitespace from the phone number
        phoneNumber = phoneNumber.replaceAll("\\s", "");
        
        // Check if the phone number is not empty, contains only digits, and has exactly 10 digits
        return !phoneNumber.isEmpty() && phoneNumber.matches("\\d{10}");
    }
}