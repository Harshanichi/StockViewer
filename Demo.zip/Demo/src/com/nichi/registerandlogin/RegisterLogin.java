package com.nichi.registerandlogin;

import com.nichi.application.Navigation;
import com.nichi.database.DataManager;

import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class RegisterLogin {
	
	public static void login(Stage primaryStage,BorderPane root,Scene scene,MenuBar bar,StackPane contentPane,HostServices host) {
	
		scene.getStylesheets().add(RegisterLogin.class.getResource("/com/nichi/application/application.css").toExternalForm());
		
		 	Label usernameLabel = new Label("Username:");
            TextField usernameField = new TextField();
            usernameField.setPromptText("Enter your username");

            Label passwordLabel = new Label("Password:");
            PasswordField passwordField = new PasswordField();
            passwordField.setPromptText("Enter your password");
            passwordField.setDisable(false); // Disable password field for demonstration

            Button submitButton = new Button("Login");
            Label resultLabel = new Label();
            // Layout the components
            VBox formLayout = new VBox(10);
            formLayout.setId("form-layout");
            formLayout.setPadding(new Insets(20));
            formLayout.getChildren().addAll(
                    new HBox(10, usernameLabel, usernameField),
                    new HBox(10, passwordLabel, passwordField),
                    submitButton,resultLabel
            );

            // Add action for submit button (just print username and password for now)
            submitButton.setOnAction(e -> {
                String username = usernameField.getText();
                String password = passwordField.getText();
                String userId =DataManager.connectDBCheck(username,password);
                System.out.println("Username: " + username + ", Password: " + password);
                System.out.println("This is userId object "+userId);
                if(userId!=null) {
                	System.out.println("Login Successful.");
                	root.setTop(bar);
                	Navigation.navBar(primaryStage,root,scene,bar,contentPane,host,userId);
                	//root.setCenter(null);
                }
                else {
                	System.out.println("Please enter valid credentials.");
                	resultLabel.getStyleClass().add("result-label");
                	resultLabel.setText("Please enter valid credentials and Try Again!");
                	root.setTop(bar);
                	root.setCenter(formLayout);
                }
            });

           root.setCenter(formLayout);

            primaryStage.setScene(scene);
            primaryStage.show();
	}

	public static void register(Stage primaryStage, BorderPane root, Scene scene,MenuBar bar) {
		// TODO Auto-generated method stub
		Label usernameLabel = new Label("Username:");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter your username");

        Label passwordLabel = new Label("Password:");
        TextField passwordField = new TextField();
        passwordField.setPromptText("Enter your password");

        Label numberLabel = new Label("Mobile Number: ");
        TextField numberField = new TextField();
        numberField.setPromptText("Enter 10 digits only");
        
        

        Button submitButton = new Button("Register");
        Label resultLabel = new Label();
        // Layout the components
        VBox formLayout = new VBox(10);
        formLayout.setId("form-layout");
        formLayout.setPadding(new Insets(20));
        formLayout.getChildren().addAll(
                new HBox(10, usernameLabel, usernameField),
                new HBox(10, passwordLabel, passwordField),
                new HBox(10, numberLabel, numberField),
                submitButton,resultLabel
        );
        
        
        	 submitButton.setOnAction(e->{
             	String uname = usernameField.getText();
             	String pass = passwordField.getText();
             	String numStr = numberField.getText();
             	
             	boolean userNameExists = DataManager.usernameExists(uname);
             	
             	if(numStr.length()!=10) {
             		Tooltip tooltip = new Tooltip("Please Enter valid Num");
                    numberField.setTooltip(tooltip);
            		numberField.setStyle("-fx-border-color: red;");
            		resultLabel.getStyleClass().add("result-label");
             		resultLabel.setText("Please enter valid Number");
             		return;
             	}
             	
             	long num = Long.parseLong(numStr);
             	
             	if(userNameExists) {
             		Tooltip tooltip = new Tooltip("Username not available");
                     usernameField.setTooltip(tooltip);
             		usernameField.setStyle("-fx-border-color: red;");
             		resultLabel.getStyleClass().add("result-label");
             		resultLabel.setText("Username Not available");
             	}
             	else {
             		
             		DataManager.connectDBRegister(uname, pass,num);
             		resultLabel.getStyleClass().add("success");
             		resultLabel.setText("Registered successfully...");
             		usernameField.setText("");
             		passwordField.setText("");
             		numberField.setText("");
             		root.setTop(bar);
                 	root.setCenter(formLayout);
             	}
             	
             	//System.out.println("Registered successfully.");
             	
             });
        
       
        root.setCenter(formLayout);
        primaryStage.setScene(scene);
        primaryStage.show();
		
	} 
		 
	

}
