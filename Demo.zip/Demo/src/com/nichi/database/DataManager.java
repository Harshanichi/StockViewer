package com.nichi.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import com.nichi.model.User;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class DataManager {

	 private static final String JDBC_URL = "jdbc:mysql://localhost:3306/userdetails";
	 
	    private static final String USERNAME = "root";
	    private static final String PASSWORD = "root";
	    
	    
	    
	    public static String connectDBCheck(String username,String password) {
	    	String query = "SELECT * FROM credentials WHERE Name = ? ";
	        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
	             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setString(1, username);
	          //  preparedStatement.setString(2, password);
	            ResultSet resultSet = preparedStatement.executeQuery();
	            if (resultSet.next()) {
	            	 String passwordQuery = "SELECT uid FROM credentials WHERE Name = ? AND password = ?";
	                 try (PreparedStatement passwordStatement = connection.prepareStatement(passwordQuery)) {
	                     passwordStatement.setString(1, username);
	                     passwordStatement.setString(2, password);
	                     ResultSet passwordResultSet = passwordStatement.executeQuery();
	                     
	                     if (passwordResultSet.next()) {
	                         return passwordResultSet.getString("uid"); // Credentials are correct
	                     } else {
	                         System.out.println("Invalid password");
	                         return null; // Incorrect password
	                     }
	                 }
	            } else {
	                System.out.println("Please get registered before logging in");
	            	return "FAIL"; // If no row is returned, the credentials are incorrect
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return null; // Return null in case of an error
	        }
	    }
	    
	    public static void connectDBRegister(String username,String password,long num) {
	    	 String query = "INSERT INTO credentials (Name, password,phone) VALUES (?, ?, ?);";
	         try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
	              PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	             preparedStatement.setString(1, username);
	             preparedStatement.setString(2, password);
	             preparedStatement.setLong(3, num);
	             int rowsAffected = preparedStatement.executeUpdate();
	             if (rowsAffected > 0) {
	                 System.out.println("User registered successfully!");
	             } else {
	                 System.out.println("User registration failed.");
	             }
	         } catch (SQLException e) {
				// TODO Auto-generated catch block
	        	 System.out.println("Please choose different username. Username not available");
				e.printStackTrace();
			}
	    }

		public static boolean usernameExists(String uname) {
			String query = "SELECT COUNT(*) FROM credentials WHERE Name = ?";
	        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
	             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setString(1, uname);
	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                if (resultSet.next()) {
	                    int count = resultSet.getInt(1);
	                    return count > 0;
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
		}

		public static void storeFeedback(String name, String email, String phone, String comments) {
			String query=" INSERT INTO feedback(name,email,phone,comments) VALUES(?,?,?,?);";
			try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
		              PreparedStatement preparedStatement = connection.prepareStatement(query)) {
		             preparedStatement.setString(1, name);
		             preparedStatement.setString(2, email);
		             preparedStatement.setString(3, phone);
		             preparedStatement.setString(4, comments);
		             preparedStatement.executeUpdate();
		             System.out.println("Feedback stored successfully.");
		            
		         } catch (SQLException e) {
					// TODO Auto-generated catch block
		        	 System.out.println("Cannot register your feedback server error");
					e.printStackTrace();
				}
			
		}
		
		public static ObservableList<User> getNames(){
			
			ObservableList<User> users = FXCollections.observableArrayList();
			
			String query="select name,number from credentials; ";
			 try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			         PreparedStatement preparedStatement = connection.prepareStatement(query);
			         ResultSet resultSet = preparedStatement.executeQuery()) {

			        while (resultSet.next()) {
			            String username = resultSet.getString("Name");
			            String number = resultSet.getString("number");
			            users.add(new User(username,number));
			        }
			    } catch (SQLException e) {
			        e.printStackTrace();
			    }

			    return users;
		}
}
