package com.nichi.database;

import java.sql.Connection; 
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.nichi.model.BhavCopyData;
import com.nichi.model.EquityData;
import com.nichi.model.HighLowData;
import com.nichi.model.TableRowData;
import com.nichi.overview.SymbolOverview;

import javafx.application.HostServices;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DataBaseManager {
//    private static final String JDBC_URL = "jdbc:mysql://192.168.1.92:3306/stocks_v2";
//    private static final String USERNAME = "test";
//    private static final String PASSWORD = "Test@123";
	private static final String JDBC_URL = "jdbc:mysql://localhost:3306/stocks_v2";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";
    public static ObservableList<BhavCopyData> gainer_data=null;
    public static ObservableList<BhavCopyData> looser_data=null;
    public static ObservableList<TableRowData> volumeGainer_data=null;
    
    public static ObservableList<BhavCopyData> fetchData(String option, Scene scene, Stage primaryStage) {
        String query = "SELECT * FROM " + option +" ;"; 
        System.out.println(query);
        ObservableList<BhavCopyData> data = null;
        ObservableList<EquityData> eq_data=null;
        ObservableList<HighLowData> hl_data=null;
        scene.getStylesheets().add(DataBaseManager.class.getResource("/com/nichi/application/application.css").toExternalForm());
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
        	System.out.println("connection established");
        	TableView<BhavCopyData> tableView = new TableView<>();
        	TableView<EquityData> tableView1 = new TableView<>();
        	TableView<HighLowData> tableView2 = new TableView<>();
        	
        	tableView.getStyleClass().add("table-view");
        	switch (option) {
                case "bhavcopy":
                    // Create table columns
                    TableColumn<BhavCopyData, String> symbolColumn = new TableColumn<>("symbol");
                    symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));

                    TableColumn<BhavCopyData, String> marketColumn = new TableColumn<>("market");
                    marketColumn.setCellValueFactory(new PropertyValueFactory<>("market"));
                    
                    TableColumn<BhavCopyData, String> seriesColumn = new TableColumn<>("series");
                    seriesColumn.setCellValueFactory(new PropertyValueFactory<>("series"));
                    
                    TableColumn<BhavCopyData, String> securityColumn = new TableColumn<>("security");
                    securityColumn.setCellValueFactory(new PropertyValueFactory<>("security"));

                    TableColumn<BhavCopyData, Double> prevColumn = new TableColumn<>("Previous Close Price");
                    prevColumn.setCellValueFactory(new PropertyValueFactory<>("prev_cl_pr"));
                    
                    TableColumn<BhavCopyData, Double> openColumn = new TableColumn<>("Open Price");
                    openColumn.setCellValueFactory(new PropertyValueFactory<>("open_price"));
                    
                    TableColumn<BhavCopyData, Double> highColumn = new TableColumn<>("High Price");
                    highColumn.setCellValueFactory(new PropertyValueFactory<>("high_price"));
                    
                    TableColumn<BhavCopyData, Double> lowColumn = new TableColumn<>("Low Price");
                    lowColumn.setCellValueFactory(new PropertyValueFactory<>("low_price"));
                    
                    TableColumn<BhavCopyData, Double> closeColumn = new TableColumn<>("Close Price");
                    closeColumn.setCellValueFactory(new PropertyValueFactory<>("close_price"));
                    
                    TableColumn<BhavCopyData, Double> netValueColumn = new TableColumn<>("Net Trade Value");
                    netValueColumn.setCellValueFactory(new PropertyValueFactory<>("net_trdval"));
                    
                    TableColumn<BhavCopyData, Integer> netQtyColumn = new TableColumn<>("Net Trade Quantity");
                    netQtyColumn.setCellValueFactory(new PropertyValueFactory<>("net_trdqty"));
                    
                    TableColumn<BhavCopyData, String> corpColumn = new TableColumn<>("Corporate Indicator");
                    corpColumn.setCellValueFactory(new PropertyValueFactory<>("corp_ind"));
                    
                    TableColumn<BhavCopyData, Double> hi52wkColumn = new TableColumn<>("52 Week High");
                    hi52wkColumn.setCellValueFactory(new PropertyValueFactory<>("hi_52_wk"));
                    
                    TableColumn<BhavCopyData, Double> lo52wkColumn = new TableColumn<>("52 Week Low");
                    lo52wkColumn.setCellValueFactory(new PropertyValueFactory<>("lo_52_wk"));
                    
                    TableColumn<BhavCopyData, Date> insertionDateColumn = new TableColumn<>("Insertion Date");
                    insertionDateColumn.setCellValueFactory(new PropertyValueFactory<>("insertion_date"));

                    // Add columns to the table
                    tableView.getColumns().addAll(symbolColumn, marketColumn, seriesColumn, securityColumn, prevColumn,
                            openColumn, highColumn, lowColumn, closeColumn, netValueColumn, netQtyColumn, corpColumn,
                            hi52wkColumn, lo52wkColumn, insertionDateColumn);
                    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
                    // Create an observable list to hold table data
                     data = FXCollections.observableArrayList();

                    // Populate the observable list with data from the ResultSet
                    while (resultSet.next()) {
                        String symbol = resultSet.getString("symbol");
                        String market = resultSet.getString("market");
                        String series = resultSet.getString("series");
                        String security = resultSet.getString("security");
                        double prev_cl_pr = resultSet.getDouble("prev_cl_pr");
                        double open_price = resultSet.getDouble("open_price");
                        double high_price = resultSet.getDouble("high_price");
                        double low_price = resultSet.getDouble("low_price");
                        double close_price = resultSet.getDouble("close_price");
                        double net_trdval = resultSet.getDouble("net_trdval");
                        int net_trdqty = resultSet.getInt("net_trdqty");
                        String corp_ind = resultSet.getString("corp_ind");
                        double hi_52_wk = resultSet.getDouble("hi_52_wk");
                        double lo_52_wk = resultSet.getDouble("lo_52_wk");
                        Date insertion_date = resultSet.getDate("insertion_date");

                        data.add(new BhavCopyData(symbol, market, series, security, prev_cl_pr, open_price, high_price,
                                low_price, close_price, net_trdval, net_trdqty, corp_ind, hi_52_wk, lo_52_wk,
                                insertion_date));
                    }


                    // Set the table data
                    tableView.setItems(data);

                    BorderPane root = (BorderPane) scene.getRoot();
                    root.setCenter(tableView);
                    break;
            
                case "equity":
                	TableColumn<EquityData, String> symbolColumnEq = new TableColumn<>("symbol");
                    symbolColumnEq.setCellValueFactory(new PropertyValueFactory<>("symbol"));
                    
                    TableColumn<EquityData, String> companynameColumnEq = new TableColumn<>("name_of_company");
                    companynameColumnEq.setCellValueFactory(new PropertyValueFactory<>("name_of_company"));
                    
                    TableColumn<EquityData, String> seriesColumnEq = new TableColumn<>("series");
                    seriesColumnEq.setCellValueFactory(new PropertyValueFactory<>("series"));
                    
                    TableColumn<EquityData, Date> dateColumnEq = new TableColumn<>("date_of_listing");
                    dateColumnEq.setCellValueFactory(new PropertyValueFactory<>("date_of_listing"));
                    
                    TableColumn<EquityData, Double> paidvalueColumnEq = new TableColumn<>("paid_up_value");
                    paidvalueColumnEq.setCellValueFactory(new PropertyValueFactory<>("paid_up_value"));
                    
                    TableColumn<EquityData, Integer> marketColumnEq = new TableColumn<>("market_lot");
                    marketColumnEq.setCellValueFactory(new PropertyValueFactory<>("market_lot"));
                    
                    TableColumn<EquityData, String> isinColumnEq = new TableColumn<>("isin_number");
                    isinColumnEq.setCellValueFactory(new PropertyValueFactory<>("isin_number"));
                	
                    TableColumn<EquityData, Double> facevalueColumnEq = new TableColumn<>("face_value");
                    facevalueColumnEq.setCellValueFactory(new PropertyValueFactory<>("face_value"));
                    
                    tableView1.getColumns().addAll(symbolColumnEq,companynameColumnEq,seriesColumnEq,dateColumnEq,paidvalueColumnEq,marketColumnEq,isinColumnEq,facevalueColumnEq);
                    tableView1.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
                    
                    eq_data = FXCollections.observableArrayList();
                    
                    while(resultSet.next()) {
                    	String symbol = resultSet.getString("symbol");
                    	String name = resultSet.getString("name_of_company");
                    	String series = resultSet.getString("series");
                    	java.util.Date date = resultSet.getDate("date_of_listing");
                    	double paid = resultSet.getDouble("paid_up_value");
                    	int market = resultSet.getInt("market_lot");
                    	String isin = resultSet.getString("isin_number");
                    	double face = resultSet.getDouble("face_value");
                    	
                    	eq_data.add(new EquityData(symbol,name,series,date,paid,market,isin,face));
                    }
                    
                    tableView1.setItems(eq_data);

                    root = (BorderPane) scene.getRoot();
                    root.setCenter(tableView1);
                    break;
                
                case "week_high_low":
                	
                	TableColumn<HighLowData, String> symbolColumn52 = new TableColumn<>("symbol");
                	symbolColumn52.setCellValueFactory(new PropertyValueFactory<>("symbol"));
                    
                    TableColumn<HighLowData, String> seriesColumn52 = new TableColumn<>("series");
                    seriesColumn52.setCellValueFactory(new PropertyValueFactory<>("series"));
                    
                    TableColumn<HighLowData, Double> adjusted_52_week_high = new TableColumn<>("adjusted_52_week_high");
                    adjusted_52_week_high.setCellValueFactory(new PropertyValueFactory<>("adjusted_52_week_high"));
                    
                    TableColumn<HighLowData, Date> week_high_date = new TableColumn<>("52_week_high_date");
                    week_high_date.setCellValueFactory(new PropertyValueFactory<>("week_high_date"));
                    
                    TableColumn<HighLowData, Double> adjusted_52_week_low = new TableColumn<>("adjusted_52_week_low");
                    adjusted_52_week_low.setCellValueFactory(new PropertyValueFactory<>("adjusted_52_week_low"));
                    
                    TableColumn<HighLowData, Date> week_low_date = new TableColumn<>("52_week_low_date");
                    week_low_date.setCellValueFactory(new PropertyValueFactory<>("week_low_date"));
                	
                    tableView2.getColumns().addAll(symbolColumn52,seriesColumn52,adjusted_52_week_high,week_high_date,adjusted_52_week_low,week_low_date);
                    tableView2.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
                    hl_data = FXCollections.observableArrayList();
                	
                    while(resultSet.next()) {
                    	String symbol = resultSet.getString("symbol");
                    	String series = resultSet.getString("series");
                    	double adjusted_week_high = resultSet.getDouble("adjusted_52_week_high");
                    	Date week_date = resultSet.getDate("52_week_high_date");
                    	double week_low = resultSet.getDouble("adjusted_52_week_low");
                    	Date low_date = resultSet.getDate("52_week_low_date");
                    	
                    	
                    	hl_data.add(new HighLowData(symbol,series,adjusted_week_high,week_date,week_low,low_date));
                    }
                    
                    tableView2.setItems(hl_data);

                    root = (BorderPane) scene.getRoot();
                    root.setCenter(tableView2);
                    break;
                  
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println(e);
        }
     return data;   
    }

    public static void calculateLosers(String option, Scene scene,Stage stage,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement()) {
            
            LocalDate currentDate = LocalDate.now();

            String query = "SELECT symbol,market,insertion_date,security,series,open_price,high_price,prev_cl_pr,low_price,close_price, close_price as Price,net_trdval,net_trdqty,corp_ind,hi_52_wk,lo_52_wk, ROUND(((close_price - prev_cl_pr)/prev_cl_pr)*100,2) as Change_percent,ROUND(close_price-((high_price+low_price+close_price)/3),2) AS pivot_deviation " +
                    "FROM bhavcopy " +
                    "WHERE insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE insertion_date <= '" + currentDate + "') " +
                    "AND ((close_price - prev_cl_pr)/prev_cl_pr)*100 < 0 order by change_percent asc";

            ResultSet resultSet = statement.executeQuery(query);

            TableView<BhavCopyData> tableView = new TableView<>();
            TableColumn<BhavCopyData, String> symbolColumn = new TableColumn<>("Symbol");
            symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));
            TableColumn<BhavCopyData, Double> priceColumn = new TableColumn<>("Price");
            priceColumn.setCellValueFactory(new PropertyValueFactory<>("close_price"));
            TableColumn<BhavCopyData, Double> changePercentColumn = new TableColumn<>("Change %");
            changePercentColumn.setCellValueFactory(new PropertyValueFactory<>("changePercent"));
            TableColumn<BhavCopyData, Double> pivotColumn = new TableColumn<>("Pivot Deviation");
            pivotColumn.setCellValueFactory(new PropertyValueFactory<>("pivot"));
            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
            
            
            symbolColumn.setCellFactory(column -> {
                TableCell<BhavCopyData, String> cell = new TableCell<BhavCopyData, String>() {
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText(empty ? null : item);
                    }
                };
                
                // Set the cursor to hand when hovering over the cell
                cell.setOnMouseEntered(event -> {
                    if (!cell.isEmpty()) {
                        scene.setCursor(Cursor.HAND);
                    }
                });
                
                // Set the cursor back to default when mouse exits the cell
                cell.setOnMouseExited(event -> scene.setCursor(Cursor.DEFAULT));

                return cell;
            });
            
            changePercentColumn.setCellFactory(column -> {
                return new TableCell<BhavCopyData, Double>() {
                    @Override
                    protected void updateItem(Double item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item == null || empty) {
                            setText(null);
                        } else {
                            setText(item.toString());
                            if (item < 0) {
                                getStyleClass().add("negative");
                            } else {
                                getStyleClass().remove("negative");
                            }
                        }
                    }
                };
            });

            // Add columns to the table view
            tableView.getColumns().addAll(symbolColumn, priceColumn, changePercentColumn,pivotColumn);

           looser_data = FXCollections.observableArrayList();
           
           while(resultSet.next()) {
        	   String sym = resultSet.getString("symbol");
        	   double close = resultSet.getDouble("price");
        	   double change = resultSet.getDouble("Change_percent");
        	   //String sym = resultSet.getString("symbol");
        	   String mark = resultSet.getString("market");
        	   String series = resultSet.getString("series");
        	   double prev_close = resultSet.getDouble("prev_cl_pr");
        	   String security = resultSet.getString("security");
        	  // double change = resultSet.getDouble("Change_percent");
        	   double open_price = resultSet.getDouble("open_price");
        	   double high_price = resultSet.getDouble("high_price");
        	   double low_price = resultSet.getDouble("low_price");
        	   //double close_price = resultSet.getDouble("close_price");
        	   double net_trdval = resultSet.getDouble("net_trdval");
        	   int nettrd_qty = resultSet.getInt("net_trdqty");
        	   String corp = resultSet.getString("corp_ind");
        	   double hi52 = resultSet.getDouble("hi_52_wk");
        	   double lo52 = resultSet.getDouble("lo_52_wk");
        	   Date insert = resultSet.getDate("insertion_date");
        	   double pivot = resultSet.getDouble("pivot_deviation");
        	   
        	   looser_data.add(new BhavCopyData(sym,mark,series,security,prev_close,open_price,high_price,low_price,close,net_trdval,nettrd_qty,corp,hi52,lo52,insert,change,pivot));
           }

           tableView.setItems(looser_data);
            // Display the table view
            BorderPane root = (BorderPane) scene.getRoot();
            root.setCenter(tableView);
            
            tableView.setOnMouseClicked(event -> {
          	   BhavCopyData selectedData = tableView.getSelectionModel().getSelectedItem();
          	   if(event.getClickCount()==1) {
          		   root.setCenter(null);
          		   SymbolOverview.displayOverview(selectedData,root,scene,stage,tableView,menuBar,host,menuAndButtons,userId);
          		   
          	   }
             });

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    
    public static void calculateGainers(String option, Scene scene,Stage stage,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {
    	scene.getStylesheets().add(DataBaseManager.class.getResource("/com/nichi/application/application.css").toExternalForm());
    	//ObservableList<BhavCopyData> gainer_data=null;
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement()) {
            
            // Get the current date
            LocalDate currentDate = LocalDate.now();

           

            // Construct SQL query to get data for the current and previous dates
            String query ="SELECT symbol,market,insertion_date,security,series,open_price,high_price,prev_cl_pr,low_price,close_price, close_price as Price,net_trdval,net_trdqty,corp_ind,hi_52_wk,lo_52_wk, ROUND(((close_price - prev_cl_pr)/prev_cl_pr)*100,2) as Change_percent, " +
                    " ROUND(close_price-((high_price+low_price+close_price)/3),2) AS pivot_deviation FROM bhavcopy " +
                    "WHERE insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE insertion_date <= '" + currentDate + "') " +
                    "AND ((close_price - prev_cl_pr)/prev_cl_pr)*100 > 0 order by change_percent desc";

            // Execute the query
            	ResultSet resultSet = statement.executeQuery(query);

            // Create a table view and set its columns
            TableView<BhavCopyData> tableView = new TableView<>();
            TableColumn<BhavCopyData, String> symbolColumn = new TableColumn<>("Symbol");
            symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));
            TableColumn<BhavCopyData, Double> priceColumn = new TableColumn<>("Price");
            priceColumn.setCellValueFactory(new PropertyValueFactory<>("close_price"));
            TableColumn<BhavCopyData, Double> changePercentColumn = new TableColumn<>("Change %");
            changePercentColumn.setCellValueFactory(new PropertyValueFactory<>("changePercent"));
            TableColumn<BhavCopyData, Double> pivotColumn = new TableColumn<>("Pivot Deviation");
            pivotColumn.setCellValueFactory(new PropertyValueFactory<>("pivot"));
            
            symbolColumn.setCellFactory(column -> {
                TableCell<BhavCopyData, String> cell = new TableCell<BhavCopyData, String>() {
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText(empty ? null : item);
                    }
                };
                
                // Set the cursor to hand when hovering over the cell
                cell.setOnMouseEntered(event -> {
                    if (!cell.isEmpty()) {
                        scene.setCursor(Cursor.HAND);
                    }
                });
                
                // Set the cursor back to default when mouse exits the cell
                cell.setOnMouseExited(event -> scene.setCursor(Cursor.DEFAULT));

                return cell;
            });
            
            
            changePercentColumn.setCellFactory(column -> {
                return new TableCell<BhavCopyData, Double>() {
                    @Override
                    protected void updateItem(Double item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item == null || empty) {
                            setText(null);
                        } else {
                            setText(item.toString());
                            if (item > 0) {
                                getStyleClass().add("positive");
                            } else {
                                getStyleClass().remove("positive");
                            }
                        }
                    }
                };
            });

            tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
            // Add columns to the table view
            tableView.getColumns().addAll(symbolColumn, priceColumn, changePercentColumn,pivotColumn);

           gainer_data = FXCollections.observableArrayList();
           
           while(resultSet.next()) {
        	   String sym = resultSet.getString("symbol");
        	   String mark = resultSet.getString("market");
        	   String series = resultSet.getString("series");
        	   double prev_close = resultSet.getDouble("prev_cl_pr");
        	   String security = resultSet.getString("security");
        	   double change = resultSet.getDouble("Change_percent");
        	   double open_price = resultSet.getDouble("open_price");
        	   double high_price = resultSet.getDouble("high_price");
        	   double low_price = resultSet.getDouble("low_price");
        	   double close_price = resultSet.getDouble("close_price");
        	   double net_trdval = resultSet.getDouble("net_trdval");
        	   int nettrd_qty = resultSet.getInt("net_trdqty");
        	   String corp = resultSet.getString("corp_ind");
        	   double hi52 = resultSet.getDouble("hi_52_wk");
        	   double lo52 = resultSet.getDouble("lo_52_wk");
        	   Date insert = resultSet.getDate("insertion_date");
        	   double pivot = resultSet.getDouble("pivot_deviation");
        	   
        	   gainer_data.add(new BhavCopyData(sym,mark,series,security,prev_close,open_price,high_price,low_price,close_price,net_trdval,nettrd_qty,corp,hi52,lo52,insert,change,pivot));
           }

           tableView.setItems(gainer_data);
           
           
            // Display the table view
            BorderPane root = (BorderPane) scene.getRoot();
            root.setCenter(tableView);
            
            tableView.setOnMouseClicked(event -> {
         	   BhavCopyData selectedData = tableView.getSelectionModel().getSelectedItem();
         	   if(event.getClickCount()==1) {
         		   root.setCenter(null);
         		   SymbolOverview.displayOverview(selectedData,root,scene,stage,tableView,menuBar,host,menuAndButtons,userId);
         		   
         	   }
            });
            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public static void fetchLongBuildUp(String option, Scene scene,Stage stage,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {
    	System.out.println("Long Build Up is yet to be developed");
    	TableView<TableRowData> tableView = new TableView<>();
    	ObservableList<TableRowData> longBuild_data=null;
    	try {
			Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			Statement stmt = connection.createStatement();
//			
			
//			String query = "SELECT today.market,today.series,today.security,today.prev_cl_pr,today.open_price,today.high_price,today.low_price,today.close_price,today.net_trdval,today.net_trdqty,today.corp_ind,today.hi_52_wk,today.lo_52_wk," + "    today.symbol," + "    today.CLOSE_PRICE AS Price,"
//					+ "    ROUND(((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100, 2) AS Change_Percent,"
//					+ "    today.insertion_date " + "FROM " + "    bhavcopy AS today " + "JOIN "
//					+ "    bhavcopy AS yesterday ON today.symbol = yesterday.symbol " + "WHERE "
//					+ "    today.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1  ) "
//					+ "    AND yesterday.insertion_date = (SELECT MAX(insertion_date)  FROM bhavcopy WHERE  yesterday.insertion_date<today.insertion_date AND DAYOFWEEK(insertion_date - INTERVAL 1 DAY) != 1 ) "
//					+ "    AND ((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100 > 0 "
//					+ "    AND (today.NET_TRDQTY >= yesterday.NET_TRDQTY) " + "ORDER BY " + "    Change_Percent DESC;";

			String query = "SELECT "
					+ "    today.market, today.series, today.security, today.prev_cl_pr, today.open_price, today.high_price, today.low_price, today.close_price, today.net_trdval, today.net_trdqty, today.corp_ind, today.hi_52_wk, today.lo_52_wk,"
					+ "    today.symbol," + "    today.close_price AS Price,"
					+ "    ROUND(((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100, 2) AS Change_Percent,"
					+ "    today.insertion_date " + "FROM " + "    bhavcopy AS today " + "JOIN "
					+ "    bhavcopy AS yesterday ON today.symbol = yesterday.symbol " + "WHERE "
					+ "    today.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1)"
					+ "    AND yesterday.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE insertion_date < (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1) AND insertion_date != (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1))"
					+ "    AND ((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100 > 0 "
					+ "    AND (today.NET_TRDQTY > yesterday.NET_TRDQTY) " + "ORDER BY "
					+ "    Change_Percent DESC;";
					
				System.out.println(query.toString()+" is from buildup");	
			
			
			
			ResultSet res = stmt.executeQuery(query);
			
			TableColumn<TableRowData, String> symbolColumn = new TableColumn<>("Symbol");
	        symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));

	        TableColumn<TableRowData, Double> priceColumn = new TableColumn<>("Price");
	        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

	        TableColumn<TableRowData, Double> longBuildupColumn = new TableColumn<>("Change%");
	        longBuildupColumn.setCellValueFactory(new PropertyValueFactory<>("longBuildup"));

	        TableColumn<TableRowData, String> insertionDateColumn = new TableColumn<>("Insertion Date");
	        insertionDateColumn.setCellValueFactory(new PropertyValueFactory<>("insertionDate"));

	        tableView.getColumns().addAll(symbolColumn, priceColumn, longBuildupColumn, insertionDateColumn);
	        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	        
	        symbolColumn.setCellFactory(column -> {
                TableCell<TableRowData, String> cell = new TableCell<TableRowData, String>() {
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText(empty ? null : item);
                    }
                };
                
                // Set the cursor to hand when hovering over the cell
                cell.setOnMouseEntered(event -> {
                    if (!cell.isEmpty()) {
                        scene.setCursor(Cursor.HAND);
                    }
                });
                
                // Set the cursor back to default when mouse exits the cell
                cell.setOnMouseExited(event -> scene.setCursor(Cursor.DEFAULT));

                return cell;
            });
	        
	        
	        
	        longBuildupColumn.setCellFactory(column -> {
                return new TableCell<TableRowData, Double>() {
                    @Override
                    protected void updateItem(Double item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item == null || empty) {
                            setText(null);
                        } else {
                            setText(item.toString());
                            if (item > 0) {
                                getStyleClass().add("positive");
                            } else {
                                getStyleClass().remove("positive");
                            }
                        }
                    }
                };
            });
	        
	        
	        longBuild_data = FXCollections.observableArrayList();
	        
	        while (res.next()) {
	        	System.out.println("Entered while");
                String symbol = res.getString("symbol");
                double price = res.getDouble("Price");
                double longBuildup = res.getDouble("Change_Percent");
                String insertionDate = res.getString("insertion_date");
                String market = res.getString("market");
                String series = res.getString("series");
                String security = res.getString("security");
                double prev = res.getDouble("prev_cl_pr");
                double open_price = res.getDouble("open_price");
                double high_price = res.getDouble("high_price");
                double low_price = res.getDouble("low_price");
                double close_price = res.getDouble("close_price");
                double net_trdval = res.getDouble("net_trdval");
                int net_trdqty = res.getInt("net_trdqty");
                String corp_ind = res.getString("corp_ind");
                double hi_52_wk = res.getDouble("hi_52_wk");
                double lo_52_wk = res.getDouble("lo_52_wk");
                System.out.println(res.next()+" long buildup");
                longBuild_data.add(new TableRowData(symbol, price, longBuildup, insertionDate,market,series,security,prev,open_price,high_price,low_price,close_price,net_trdval,net_trdqty,corp_ind,hi_52_wk,lo_52_wk));
            }
			
	        tableView.setItems(longBuild_data);
            // Display the table view
            BorderPane root = (BorderPane) scene.getRoot();
            root.setCenter(tableView);
            
            
            tableView.setOnMouseClicked(event -> {
           	   TableRowData selectedData = tableView.getSelectionModel().getSelectedItem();
           	   if(event.getClickCount()==1) {
           		   root.setCenter(null);
           		   SymbolOverview.displayOverview(selectedData,root,scene,stage,tableView,menuBar,host,menuAndButtons,userId);
           		   
           	   }
              });
			
			System.out.println("Query Executed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
   

    public static void fetchShortBuildUp(String option, Scene scene,Stage stage,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {
    	
    	TableView<TableRowData> tableView = new TableView<>();
    	ObservableList<TableRowData> shortBuild_data=null;
    	try {
			Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			Statement stmt = connection.createStatement();
//			
			
//			String query = "SELECT today.symbol,today.close_price,today.market,today.series,today.security,today.prev_cl_pr,today.open_price,today.high_price,today.low_price,today.net_trdval,today.net_trdqty,today.corp_ind,today.hi_52_wk,today.lo_52_wk,today.CLOSE_PRICE AS Price, "
//					+ "    ROUND(((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100, 2) AS Change_Percent ,"
//					+ "    today.insertion_date " + "FROM " + "    bhavcopy AS today " + "JOIN "
//					+ "    bhavcopy AS yesterday ON today.symbol = yesterday.symbol " + "WHERE "
//					+ "    today.insertion_date = (" + "        SELECT MAX(insertion_date) " + "        FROM bhavcopy "
//					+ "        WHERE DAYOFWEEK(insertion_date) != 1 " + "    )"
//					+ "    AND yesterday.insertion_date = ( " + "        SELECT MAX(insertion_date)  "
//					+ "        FROM bhavcopy " + "        WHERE DAYOFWEEK(insertion_date - INTERVAL 1 DAY) != 1 AND yesterday.insertion_date<today.insertion_date "
//					+ "    ) " + "    AND ((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100 < 0 "
//					+ "    AND (today.NET_TRDQTY < yesterday.NET_TRDQTY) " + "ORDER BY " + "    Change_Percent ASC;";

					
			String query = "SELECT "
					+ "    today.market, today.series, today.security, today.prev_cl_pr, today.open_price, today.high_price, today.low_price, today.close_price, today.net_trdval, today.net_trdqty, today.corp_ind, today.hi_52_wk, today.lo_52_wk,"
					+ "    today.symbol," + "    today.close_price AS Price,"
					+ "    ROUND(((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100, 2) AS Change_Percent,"
					+ "    today.insertion_date " + "FROM " + "    bhavcopy AS today " + "JOIN "
					+ "    bhavcopy AS yesterday ON today.symbol = yesterday.symbol " + "WHERE "
					+ "    today.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1)"
					+ "    AND yesterday.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE insertion_date < (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1) AND insertion_date != (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date) != 1))"
					+ "    AND ((today.close_price - today.prev_cl_pr) / today.prev_cl_pr) * 100 < 0 "
					+ "    AND (today.NET_TRDQTY > yesterday.NET_TRDQTY) " + "ORDER BY "
					+ "    Change_Percent ASC;";	
			
			
			
			ResultSet res = stmt.executeQuery(query);
			
			TableColumn<TableRowData, String> symbolColumn = new TableColumn<>("Symbol");
	        symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));

	        TableColumn<TableRowData, Double> priceColumn = new TableColumn<>("Price");
	        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

	        TableColumn<TableRowData, Double> longBuildupColumn = new TableColumn<>("Change%");
	        longBuildupColumn.setCellValueFactory(new PropertyValueFactory<>("shortBuildup"));

	        TableColumn<TableRowData, String> insertionDateColumn = new TableColumn<>("Insertion Date");
	        insertionDateColumn.setCellValueFactory(new PropertyValueFactory<>("insertionDate"));

	        tableView.getColumns().addAll(symbolColumn, priceColumn, longBuildupColumn, insertionDateColumn);
	        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	        
	        
	        
	        symbolColumn.setCellFactory(column -> {
                TableCell<TableRowData, String> cell = new TableCell<TableRowData, String>() {
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText(empty ? null : item);
                    }
                };
                
                // Set the cursor to hand when hovering over the cell
                cell.setOnMouseEntered(event -> {
                    if (!cell.isEmpty()) {
                        scene.setCursor(Cursor.HAND);
                    }
                });
                
                // Set the cursor back to default when mouse exits the cell
                cell.setOnMouseExited(event -> scene.setCursor(Cursor.DEFAULT));

                return cell;
            });
	        
	        
	        
	        longBuildupColumn.setCellFactory(column -> {
                return new TableCell<TableRowData, Double>() {
                    @Override
                    protected void updateItem(Double item, boolean empty) {
                        super.updateItem(item, empty);
                        if (item == null || empty) {
                            setText(null);
                        } else {
                            setText(item.toString());
                            if (item < 0) {
                                getStyleClass().add("negative");
                            } else {
                                getStyleClass().remove("negative");
                            }
                        }
                    }
                };
            });

	        
	        
	        shortBuild_data = FXCollections.observableArrayList();
	        
	        while (res.next()) {
                String symbol = res.getString("symbol");
                double price = res.getDouble("Price");
                double shortBuildup = res.getDouble("Change_Percent");
                String insertionDate = res.getString("insertion_date");
                String market = res.getString("market");
                String series = res.getString("series");
                String security = res.getString("security");
                double prev = res.getDouble("prev_cl_pr");
                double open_price = res.getDouble("open_price");
                double high_price = res.getDouble("high_price");
                double low_price = res.getDouble("low_price");
                double close_price = res.getDouble("close_price");
                double net_trdval = res.getDouble("net_trdval");
                int net_trdqty = res.getInt("net_trdqty");
                String corp_ind = res.getString("corp_ind");
                double hi_52_wk = res.getDouble("hi_52_wk");
                double lo_52_wk = res.getDouble("lo_52_wk");

                shortBuild_data.add(new TableRowData(price, symbol, shortBuildup, insertionDate,market,series,security,prev,open_price,high_price,low_price,close_price,net_trdval,net_trdqty,corp_ind,hi_52_wk,lo_52_wk));
            }
			
	        tableView.setItems(shortBuild_data);
            // Display the table view
            BorderPane root = (BorderPane) scene.getRoot();
            root.setCenter(tableView);
            tableView.setOnMouseClicked(event -> {
         	   TableRowData selectedData = tableView.getSelectionModel().getSelectedItem();
         	   if(event.getClickCount()==1) {
         		   root.setCenter(null);
         		   SymbolOverview.displayOverview(selectedData,root,scene,stage,tableView,menuBar,host,menuAndButtons,userId);
         		   
         	   }
            });
			System.out.println("Query Executed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	public static void fetchVolumeGainers(String string, Scene scene,Stage stage,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {
		TableView<TableRowData> tableViewVolume = new TableView<>();
    	
    	try {
			Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
			Statement stmt = connection.createStatement();

			
			String query = "SELECT " + "    today.symbol,today.close_price,today.market,today.series,today.security,today.prev_cl_pr,today.open_price,today.high_price,today.low_price,today.net_trdval,today.net_trdqty,today.corp_ind,today.hi_52_wk,today.lo_52_wk," + "    today.CLOSE_PRICE AS Price,"
					+ "    ROUND(((today.CLOSE_PRICE - today.PREV_CL_PR) / today.PREV_CL_PR) * 100, 2) AS Price_Change_Percent,"
					+ "    ROUND(((today.NET_TRDQTY - yesterday.NET_TRDQTY) / yesterday.NET_TRDQTY) * 100, 2) AS Volume_Change_Percent"
					+ " FROM " + "    bhavcopy AS today " + "JOIN "
					+ "    bhavcopy AS yesterday ON today.symbol = yesterday.symbol " + "WHERE "
					+ "    today.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy)"
					+ "    AND yesterday.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date - INTERVAL 1 DAY) != 1 AND insertion_date < today.insertion_date )"
					+"ORDER BY "  + "    Volume_Change_Percent DESC;";

					//"GROUP BY " + "    today.symbol " +
					
			
			
			
			ResultSet res = stmt.executeQuery(query);
			
			TableColumn<TableRowData, String> symbolColumn = new TableColumn<>("Symbol");
	        symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));

	        TableColumn<TableRowData, Double> priceColumn = new TableColumn<>("Price");
	        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

	        TableColumn<TableRowData, Double> volumeColumn = new TableColumn<>("Volume Change%");
	        volumeColumn.setCellValueFactory(new PropertyValueFactory<>("volume"));

	        TableColumn<TableRowData, Double> changeColumn = new TableColumn<>("Change%");
	        changeColumn.setCellValueFactory(new PropertyValueFactory<>("change_percent"));

	        tableViewVolume.getColumns().addAll(symbolColumn, priceColumn, volumeColumn, changeColumn);
	        tableViewVolume.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	        
	        
	        symbolColumn.setCellFactory(column -> {
                TableCell<TableRowData, String> cell = new TableCell<TableRowData, String>() {
                    @Override
                    protected void updateItem(String item, boolean empty) {
                        super.updateItem(item, empty);
                        setText(empty ? null : item);
                    }
                };
                
                // Set the cursor to hand when hovering over the cell
                cell.setOnMouseEntered(event -> {
                    if (!cell.isEmpty()) {
                        scene.setCursor(Cursor.HAND);
                    }
                });
                
                // Set the cursor back to default when mouse exits the cell
                cell.setOnMouseExited(event -> scene.setCursor(Cursor.DEFAULT));

                return cell;
            });
	        
	        changeColumn.setCellFactory(column -> {
	            return new TableCell<TableRowData, Double>() {
	                @Override
	                protected void updateItem(Double item, boolean empty) {
	                    super.updateItem(item, empty);
	                    if (item == null || empty) {
	                        setText(null);
	                        setStyle(""); // Clear any existing styles
	                    } else {
	                        setText(item.toString());
	                        if (item < 0) {
	                            setStyle("-fx-text-fill: red;"); // Set text color to red for negative values
	                        } else if (item > 0) {
	                            setStyle("-fx-text-fill: green;"); // Set text color to green for positive values
	                        } else {
	                            setStyle(""); // Clear any existing styles if the value is zero
	                        }
	                    }
	                }
	            };
	        });


	        
	        
	        volumeGainer_data = FXCollections.observableArrayList();
	        
	        while (res.next()) {
                String symbol = res.getString("symbol");
                double price = res.getDouble("Price");
                double volume = res.getDouble("Volume_Change_Percent");
                double change = res.getDouble("Price_Change_Percent");
                String market = res.getString("market");
                String series = res.getString("series");
                String security = res.getString("security");
                double prev = res.getDouble("prev_cl_pr");
                double open_price = res.getDouble("open_price");
                double high_price = res.getDouble("high_price");
                double low_price = res.getDouble("low_price");
                double close_price = res.getDouble("close_price");
                double net_trdval = res.getDouble("net_trdval");
                int net_trdqty = res.getInt("net_trdqty");
                String corp_ind = res.getString("corp_ind");
                double hi_52_wk = res.getDouble("hi_52_wk");
                double lo_52_wk = res.getDouble("lo_52_wk");
                

                volumeGainer_data.add(new TableRowData(symbol, price, volume, change,market,series,security,prev,open_price,high_price,low_price,close_price,net_trdval,net_trdqty,corp_ind,hi_52_wk,lo_52_wk));
            }
			
	        tableViewVolume.setItems(volumeGainer_data);
            // Display the table view
            BorderPane root = (BorderPane) scene.getRoot();
            root.setCenter(tableViewVolume);
			
            tableViewVolume.setOnMouseClicked(event -> {
          	   TableRowData selectedData = tableViewVolume.getSelectionModel().getSelectedItem();
          	   if(event.getClickCount()==1) {
          		   root.setCenter(null);
          		   SymbolOverview.displayOverview(selectedData,root,scene,stage,tableViewVolume,menuBar,host,menuAndButtons,userId);
          		   
          	   }
             });
            
			System.out.println("Query Executed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

	 public static List<BhavCopyData> searchQuery(String symbol) {
	        
		 List<BhavCopyData> searchData = new ArrayList<>();
	        String query = "SELECT *,ROUND(((close_price - prev_cl_pr)/prev_cl_pr) * 100) AS changePercent FROM bhavcopy WHERE symbol LIKE ? ORDER BY insertion_date DESC ";
	        
	        try (Connection connection = DriverManager.getConnection(JDBC_URL,USERNAME,PASSWORD);
	             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            // Set the symbol parameter in the prepared statement
	            preparedStatement.setString(1, symbol+"%");

	            // Execute the query
	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                // Iterate through the result set and populate the searchData list
	            	while (resultSet.next()) {
	                    // Construct a StockData object for each row in the result set
	                    BhavCopyData stockData = new BhavCopyData(
	                        resultSet.getString("symbol"),
	                        resultSet.getString("market"),
	                        resultSet.getString("series"),
	                        resultSet.getString("security"),
	                        resultSet.getDouble("prev_cl_pr"),
	                        resultSet.getDouble("open_price"),
	                        resultSet.getDouble("high_price"),
	                        resultSet.getDouble("low_price"),
	                        resultSet.getDouble("close_price"),
	                        resultSet.getDouble("net_trdval"),
	                        resultSet.getInt("net_trdqty"),
	                        resultSet.getString("corp_ind"),
	                        resultSet.getDouble("hi_52_wk"),
	                        resultSet.getDouble("lo_52_wk"),
	                        resultSet.getDate("insertion_date"),
	                        resultSet.getDouble("changePercent")
	                        
	                    );
	                    // Add the StockData object to the searchData list
	                    searchData.add(stockData);
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace(); // Handle the exception appropriately
	        }

	        return searchData;
	    }

	 
	 
	 public static List<Date> fetchInsertionDates(String symbol) throws SQLException {
		    List<Date> insertionDates = new ArrayList<>();
		    String query = "SELECT insertion_date FROM bhavcopy WHERE symbol = ?";
		    try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
		         PreparedStatement statement = connection.prepareStatement(query)) {
		        statement.setString(1, symbol);
		        try (ResultSet resultSet = statement.executeQuery()) {
		            while (resultSet.next()) {
		                insertionDates.add(resultSet.getDate("insertion_date"));
		            }
		        }
		    }
		    return insertionDates;
		}

		public static List<Double> fetchClosePrices(String symbol) throws SQLException {
		    List<Double> closePrices = new ArrayList<>();
		    String query = "SELECT close_price FROM bhavcopy WHERE symbol = ?";
		    try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
		         PreparedStatement statement = connection.prepareStatement(query)) {
		        statement.setString(1, symbol);
		        try (ResultSet resultSet = statement.executeQuery()) {
		            while (resultSet.next()) {
		                closePrices.add(resultSet.getDouble("close_price"));
		            }
		        }
		    }
		    return closePrices;
		}
		
		
		public static List<Double> fetchVolumeChange(String symbol) throws SQLException {
		    List<Double> volumeChange = new ArrayList<>();
		    String query = "SELECT ROUND(((today.NET_TRDQTY - yesterday.NET_TRDQTY) / yesterday.NET_TRDQTY) * 100, 2) AS Volume_Change_Percent FROM bhavcopy AS today WHERE symbol = ?" + "JOIN "
					+ "    bhavcopy AS yesterday ON today.symbol = yesterday.symbol " + "WHERE "
					+ "    today.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy)"
					+ "    AND yesterday.insertion_date = (SELECT MAX(insertion_date) FROM bhavcopy WHERE DAYOFWEEK(insertion_date - INTERVAL 1 DAY) != 1 AND insertion_date < today.insertion_date )";
		    try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
		         PreparedStatement statement = connection.prepareStatement(query)) {
		        statement.setString(1, symbol);
		        try (ResultSet resultSet = statement.executeQuery()) {
		            while (resultSet.next()) {
		            	volumeChange.add(resultSet.getDouble("Volume_Change_Percent"));
		            }
		        }
		    }
		    return volumeChange;
		}

		 public static void connectDBRegister(String username,String password) {
	    	 String query = "INSERT INTO credentials (username, password) VALUES (?, ?);";
	         try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
	              PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	             preparedStatement.setString(1, username);
	             preparedStatement.setString(2, password);
	             int rowsAffected = preparedStatement.executeUpdate();
	             if (rowsAffected > 0) {
	                 System.out.println("User registered successfully!");
	             } else {
	                 System.out.println("User registration failed.");
	             }
	         } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
		 
		 public static boolean connectDBCheck(String username,String password) {
		    	String query = "SELECT * FROM credentials WHERE username = ? AND password = ?";
		        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
		             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
		            preparedStatement.setString(1, username);
		            preparedStatement.setString(2, password);
		            ResultSet resultSet = preparedStatement.executeQuery();
		            return resultSet.next(); // If a row is returned, the credentials are correct
		        } catch (SQLException e) {
		            e.printStackTrace();
		            return false; // Return false in case of an error
		        }
		    }
		
	public static String getLatestMarketData(String symbol) {
		String query="select market from bhavcopy where symbol = ? AND insertion_date = (select max(insertion_date) from bhavcopy where symbol = ? )";
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stocks_v2", "root", "root");
		         PreparedStatement statement = connection.prepareStatement(query)) {
		        
		        statement.setString(1, symbol);
		        statement.setString(2, symbol);
		        
		        try (ResultSet resultSet = statement.executeQuery()) {
		            if (resultSet.next()) {
		                String market = resultSet.getString("market");
		            	return market;
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		return null;
	}

	public static String getLatestSeriesData(String symbol) {
		String query="select series from bhavcopy where symbol = ? AND insertion_date = (select max(insertion_date) from bhavcopy where symbol = ? )";
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stocks_v2", "root", "root");
		         PreparedStatement statement = connection.prepareStatement(query)) {
		        
		        statement.setString(1, symbol);
		        statement.setString(2, symbol);
		        
		        try (ResultSet resultSet = statement.executeQuery()) {
		            if (resultSet.next()) {
		                String series = resultSet.getString("series");
		            	return series;
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		return null;
	}

	public static double getLatestOpenPriceData(String symbol) {
		String query="select open_price from bhavcopy where symbol = ? AND insertion_date = (select max(insertion_date) from bhavcopy where symbol = ? )";
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/stocks_v2", "root", "root");
		         PreparedStatement statement = connection.prepareStatement(query)) {
		        
		        statement.setString(1, symbol);
		        statement.setString(2, symbol);
		        
		        try (ResultSet resultSet = statement.executeQuery()) {
		            if (resultSet.next()) {
		                double open_price = resultSet.getDouble("open_price");
		            	return open_price;
		            }
		        }
		    } catch (SQLException e) {
		        e.printStackTrace();
		    }
		return 0;
	}

}
