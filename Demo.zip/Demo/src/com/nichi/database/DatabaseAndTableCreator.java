package com.nichi.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;





public class DatabaseAndTableCreator {
	private static String dataBaseName = "userdetails";
	private static String url = "jdbc:mysql://localhost:3306/";
	private static String username = "root";
	private static String password = "root";
	
	public static void createDatabaseIfNotExists() {
		try (Connection connection = getConnection()) {
			Statement statement = connection.createStatement();
			String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " + dataBaseName;
			statement.executeUpdate(createDatabaseQuery);
			System.out.println("Database '" + dataBaseName + "' created successfully.");
		} catch (SQLException sqlException) {
			handleSQLException(sqlException);
		} 
	}

	private static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, username, password);
	}

	private static void handleSQLException(SQLException e) {
		System.out.println("Error occurred while creating the database:");
		e.printStackTrace();
	}
	
	public static void createAllTables() {
		System.out.println("Inside create All table method");
		try(Connection connection = getDbConnection()) {
			
			createCredentialsTable(connection,"credentials");
			createFeedbackTable(connection,"feedback");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	private static void createCredentialsTable(Connection connection,String tableName) {
		
		String columns = " uid int auto_increment not null, name varchar(10), password varchar(20), phone varchar(20), PRIMARY KEY(uid)";
		
		createTable(connection,tableName,columns);
	}
	
	private static void createFeedbackTable(Connection connection,String tableName) {
		String columns = "name varchar(10),email varchar(50), phone varchar(20), comments varchar(255)";
		createTable(connection,tableName,columns);
	}
	
	private static void createTable(Connection connection, String tableName, String columns) {
		
		try (Statement statement = connection.createStatement()) {
		
			
			String createTableQuery = "CREATE TABLE IF NOT EXISTS " + tableName + " (" + columns + ")";
			
			int res = statement.executeUpdate(createTableQuery);
			System.out.println("Response: "+res);
			System.out.println("Table '" + tableName + "' created successfully.");

		} catch (Exception e) {
			e.getStackTrace();
			System.out.println(e.getMessage());
			
		}
	}
	
	private static Connection getDbConnection() {
		
		Connection connection = null;
		try {
			if (connection == null || connection.isClosed()) {
				
				String link = url + dataBaseName;
				String name = username;
				String pwd = password;
				connection = DriverManager.getConnection(link, name, pwd);
				
			}
		} catch (SQLException e) {
			System.out.println("Error in Connection to Database.");
		}
		return connection;
	}
}
