package com.nichi.application;

import javafx.application.HostServices;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.ObjectInputStream.GetField;
import java.util.Collections;
import java.util.List;
import java.util.Observable;

import com.nichi.database.DataBaseManager;
import com.nichi.feedback.Contact;
import com.nichi.feedback.Feedback;
import com.nichi.model.BhavCopyData;
import com.nichi.model.TableRowData;
import com.nichi.overview.SymbolGraph;
import com.nichi.overview.SymbolOverview;
import com.nichi.wishlist.Stock;

import com.nichi.wishlist.WishlistManager;


public class Navigation {
	public static MenuBar menuBar;
	public static MenuBar bottomMenuBar;

	
	public static void navBar(Stage primaryStage,BorderPane root,Scene scene,MenuBar bar,StackPane contentPane,HostServices host,String userId) {

		try {

            
            VBox menuAndButtons = new VBox();
            HBox buttonBox = new HBox();
            
            menuBar = new MenuBar();
            menuBar.getStyleClass().add("menu-item");
            
            DataBaseManager.calculateGainers("bhavcopy", scene, primaryStage,menuBar,host,menuAndButtons,userId);
            DataBaseManager.calculateLosers("bhavcopy", scene, primaryStage,menuBar,host,menuAndButtons,userId);
            DataBaseManager.fetchVolumeGainers("bhavcopy", scene, primaryStage,menuBar,host,menuAndButtons,userId);
            
            ImageView imageView = new ImageView(new Image(Navigation.class.getResourceAsStream("nichilogo.png")));
            VBox.setVgrow(imageView, Priority.ALWAYS); // Allow the image to grow vertically
            VBox homeContent = new VBox(imageView); // Wrap the image in a VBox
            homeContent.setAlignment(Pos.CENTER); // Center align the image
            root.setCenter(homeContent);
            
            
            
            Menu home = new Menu("Home");
            
            MenuItem homemenu = new MenuItem("Go To Home ");
            homemenu.setOnAction(e -> {
            						root.setCenter(null);
            						ImageView imageView1 = new ImageView(new Image(Navigation.class.getResourceAsStream("nichilogo.png")));
            			            VBox.setVgrow(imageView1, Priority.ALWAYS); // Allow the image to grow vertically
            			            VBox homeContent1 = new VBox(imageView1); // Wrap the image in a VBox
            			            homeContent1.setAlignment(Pos.CENTER); // Center align the image
            			            root.setCenter(homeContent1); // Set the home content in the center
            						
            						SymbolGraph.plotHomeGraph(DataBaseManager.gainer_data,DataBaseManager.looser_data,DataBaseManager.volumeGainer_data,root,scene,primaryStage);
            						menuAndButtons.getChildren().clear(); 
            						 root.setTop(menuBar);
            						menuAndButtons.getChildren().addAll(menuBar, buttonBox);
            						root.setBottom(null);
            						root.setRight(homeContent1);
            						root.setTop(menuAndButtons);
            						System.out.println("Home Button clicked");
            });
            
            Menu marketMenu = new Menu("Markets");
            Menu intraMenu = new Menu("IntraDay");
            Menu futuresMenu = new Menu("Futures");
            Menu options = new Menu("Options");
            Menu eodScan = new Menu("Eod Scans");
            Menu displayData = new Menu("Display Data");
            Menu contactUs = new Menu("Contact Us");
            
            
           MenuItem contact = new MenuItem("Contact");
           MenuItem feedback = new MenuItem("Feedback");
           contact.setOnAction(e->{
        	   System.out.println("contact us is not yet implemented");
        	   Contact.getContact(primaryStage,root,scene,menuBar);
           });
           feedback.setOnAction(e->{
        	   System.out.println("Thanks for your patience, we are not accepting feedback for now.");
        	   Feedback.getFeedback(primaryStage,root,scene,menuBar);
           });
           
            MenuItem openMenuItem = new MenuItem("Bhav Copy");
            openMenuItem.setOnAction(e -> {
                // Assuming you have a reference to the primaryStage in your SampleController
            	root.setBottom(null);
            	root.setRight(null);
            	root.setCenter(null);
                root.setTop(menuBar);
            	DataBaseManager.fetchData("bhavcopy", scene, primaryStage);
            });
            
            MenuItem eq_menu = new MenuItem("Equity");
            eq_menu.setOnAction(e->{
            	root.setBottom(null);
            	root.setRight(null);
            	root.setCenter(null);
                root.setTop(menuBar);
            	DataBaseManager.fetchData("equity", scene, primaryStage);
            });
            
            MenuItem week_highLow_menu = new MenuItem("52 Week High Low");
            week_highLow_menu.setOnAction(e->{
            	root.setBottom(null);
            	root.setRight(null);
            	root.setCenter(null);
                root.setTop(menuBar);
                DataBaseManager.fetchData("week_high_low", scene, primaryStage);
            });
            home.getItems().addAll(homemenu);
            contactUs.getItems().addAll(contact,feedback);
            displayData.getItems().addAll(openMenuItem,eq_menu,week_highLow_menu);
            menuBar.getMenus().addAll(home,marketMenu, intraMenu, futuresMenu, options, eodScan, displayData,contactUs);

           
            Button topGainersButton = new Button("Gainers");
            Button topLosersButton = new Button("Losers");
            topGainersButton.getStyleClass().add("button-78");
            topLosersButton.getStyleClass().add("button-78");
            // Set actions for buttons (for demonstration)
            topGainersButton.setOnAction(e -> {
                System.out.println("Switching to Top Gainers");
                root.setBottom(null);
                root.setRight(null);
                DataBaseManager.calculateGainers("bhavcopy",scene,primaryStage,menuBar,host,menuAndButtons,userId);
                System.out.println("Done Something.");
            });
            topLosersButton.setOnAction(e -> {
                // Handle switching to top losers tab
            	//root.setCenter(null);
            	root.setBottom(null);
            	root.setRight(null);
            	System.out.println("Switching to Top Losers");
                DataBaseManager.calculateLosers("bhavcopy", scene,primaryStage,menuBar,host,menuAndButtons,userId);
            });

            
            Button longBuildUpButton = new Button("Long Build-Up");
            Button shortBuildUpButton = new Button("Short Build-Up");
            Button volumeGainersButton = new Button("Volume Gainers");
            volumeGainersButton.getStyleClass().add("button-78");
            longBuildUpButton.getStyleClass().add("button-78");
            shortBuildUpButton.getStyleClass().add("button-78");
            HBox.setHgrow(buttonBox, Priority.ALWAYS);
            
            longBuildUpButton.setOnAction(e-> {
            	root.setBottom(null);
            	root.setRight(null);
            	System.out.println("Long Buildup Button is clicked");
            	DataBaseManager.fetchLongBuildUp("bhavcopy",scene,primaryStage,menuBar,host,menuAndButtons,userId);
            });
            
            shortBuildUpButton.setOnAction(e-> {
            	root.setRight(null);
            	root.setBottom(null);
            	System.out.println("Short Buildup Button is clicked");
            	DataBaseManager.fetchShortBuildUp("bhavcopy",scene,primaryStage,menuBar,host,menuAndButtons,userId);
            });
            
            volumeGainersButton.setOnAction(e-> {
            	root.setBottom(null);
            	root.setRight(null);
            	System.out.println("Volume Gainers Button is clicked");
            	DataBaseManager.fetchVolumeGainers("bhavcopy",scene,primaryStage,menuBar,host,menuAndButtons,userId);
            });
            
            
           
            
            TextField search = new TextField();
            search.getStyleClass().add("search-container");
            search.setPromptText("Search Stocks");
            search.autosize();
            
            search.setOnAction(e->{
            	root.setBottom(null);
            	root.setRight(null);
            	System.out.println("Yet to be implemented");
            	String symbol=search.getText();
            	List<BhavCopyData> searchResult = DataBaseManager.searchQuery(symbol);
            	displaySearchResults(searchResult,root);
            });
            
            search.textProperty().addListener((observable, oldValue, newValue) -> {
                root.setBottom(null);
                root.setRight(null);
                System.out.println("Yet to be implemented");
                String partialSymbol = newValue; // Use the new value of the text field

                // Check if the search query is not empty
                if (!partialSymbol.isEmpty()) {
                    // Fetch the data from the database for the partial symbol
                    List<BhavCopyData> searchResult = DataBaseManager.searchQuery(partialSymbol);
                    displaySearchResults(searchResult,root);
                } else {
                    // If the search query is empty, clear the search results
                    displaySearchResults(Collections.emptyList(),root);
                }
            });
            
            Button wishListButton = new Button("WishList");
            
            wishListButton.setOnMouseEntered(e->{
            	wishListButton.setCursor(Cursor.HAND);
            });
            wishListButton.setOnAction(e->{
            	System.out.println("WishList is clicked");
            	root.setCenter(null);
            	root.setRight(null);
            	root.setBottom(null);
            	List<Object> wishListData = WishlistManager.getInstance().getWishlistData(userId);
            	System.out.println(wishListData);
            	System.out.println(WishlistManager.getInstance().getWishlistData(userId).toString());
            	displayWishlistData(wishListData, root,scene, primaryStage,userId,host,menuAndButtons);
            });
            
            Button logout = new Button("LogOut");
            
            buttonBox.getChildren().addAll(topGainersButton, topLosersButton,longBuildUpButton,shortBuildUpButton,volumeGainersButton,wishListButton,search,logout);

            // Use VBox to stack the menu bar and buttons
            
            logout.setOnAction(e->{
            	System.out.println("Clicked on logout.");
            	root.setCenter(contentPane);
            	root.setTop(bar);
            	root.setRight(null);
            	root.setBottom(null);
            });

            menuAndButtons.getChildren().addAll(menuBar, buttonBox);

            // Add VBox to the top of the BorderPane
            root.setTop(menuAndButtons);
            
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

	
	
	public static ScrollPane scrollPane=null;
	public static BhavCopyData selectedData = null;
	public static void displayWishlistData(List<Object> wishlistData, BorderPane root,Scene scene, Stage stage, String userId,HostServices host,VBox menuAndButtons) {
	    
		
		if (wishlistData.isEmpty()) {
	        // Clear the center of the BorderPane
	        root.setCenter(null);
	        
	        // Create a watermark-style label
	        Label watermarkLabel = new Label("Your Wishlist is empty");
	        watermarkLabel.setStyle("-fx-font-size: 24px; -fx-opacity: 0.5;"); // Set font size and opacity
	        watermarkLabel.setAlignment(Pos.CENTER); // Align the label to the center
	        
	        // Add the watermark label to the center of the BorderPane
	        root.setCenter(watermarkLabel);
	        
	        return;
	    }

	    // Create a VBox to hold the wishlist items
	    VBox wishlistContainer = new VBox();
	    wishlistContainer.setSpacing(20); // Set spacing between wishlist items
	    
	    
	    
	    // Iterate through each wishlist item
	    for (Object item : wishlistData) {
	    	
	        // Create a VBox to hold each wishlist item and its controls
	        VBox wishlistItemBox = new VBox();
	        wishlistItemBox.setStyle("-fx-border-color: #CCCCCC; -fx-border-width: 1px; -fx-padding: 10px;");
	        wishlistItemBox.setSpacing(5); // Set spacing between item details and buttons

	        // Create labels to display item details (symbol and name)
	        Label nameLabel = new Label();
	        Label symbolLabel = new Label();

	        
	       
	        // Set the item details (replace "getName" and "getSymbol" with actual methods)
	        if (item instanceof Stock) {
	        	
	        	
	            Stock stockItem = (Stock) item;
	            String series = stockItem.getSeries();
	            nameLabel.setText("Name: " + stockItem.getName());
	            symbolLabel.setText("Symbol: " + stockItem.getSymbol());
	            selectedData = createBhavCopyDataFromStock(stockItem);
	            System.out.println(selectedData.getChangePercent()+" This is the thing youre are currently checking.");
	        }

	        // Create buttons for viewing and deleting the wishlist item
	        Button viewButton = new Button("View");
	        Button deleteButton = new Button("Delete");

	        // Set styles for buttons
	        viewButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white;");
	        deleteButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white;");

	        // Set actions for the view and delete buttons
	        viewButton.setOnAction(e -> {
	            
	        	if(selectedData!=null) {
	        		System.out.println("Clicked on view button");
		            root.setCenter(null);
		           
		            
	      		   SymbolOverview.displayOverview(selectedData,root,scene,stage,scrollPane,menuBar,host,menuAndButtons,userId);
	        	}
	        	else {
	        		System.out.println("It is in else block of view button");
	        	}
	           
	        });
	        deleteButton.setOnAction(e -> {
	            System.out.println("Deleted Item " + item);
	            // Handle delete action, e.g., remove from wishlist
	            WishlistManager.getInstance().removeFromWishlist(userId, item);
	            // Refresh the wishlist display
	            displayWishlistData(WishlistManager.getInstance().getWishlistData(userId), root,scene, stage, userId,host,menuAndButtons);
	        });

	        // Add the components to the wishlist item VBox
	        wishlistItemBox.getChildren().addAll(nameLabel, symbolLabel, viewButton, deleteButton);

	        // Add the wishlist item VBox to the wishlist container
	        wishlistContainer.getChildren().add(wishlistItemBox);
	    }

	    // Create a ScrollPane and set its content to the wishlist container
	    scrollPane = new ScrollPane(wishlistContainer);
	    scrollPane.setFitToWidth(true); // Allow the scroll pane to resize horizontally
	    scrollPane.setFitToHeight(true); // Allow the scroll pane to resize vertically

	    // Set the scroll pane as the center of the BorderPane
	    root.setCenter(scrollPane);
	}


	public static BhavCopyData createBhavCopyDataFromStock(Stock stock) {
	    BhavCopyData bhavCopyData = new BhavCopyData();
	    
	    // Map fields from Stock to BhavCopyData
	    bhavCopyData.setSymbol(stock.getSymbol());
	    bhavCopyData.setMarket(DataBaseManager.getLatestMarketData(stock.getSymbol()));
	    bhavCopyData.setSeries(DataBaseManager.getLatestSeriesData(stock.getSymbol()));
	    bhavCopyData.setSecurity(stock.getName());
	    bhavCopyData.setOpen_price(DataBaseManager.getLatestOpenPriceData(stock.getSymbol()));
	    bhavCopyData.setHigh_price(stock.getHigh_price());
	    bhavCopyData.setLow_price(stock.getLow_price());
	    bhavCopyData.setClose_price(stock.getClose_price());
	    bhavCopyData.setNet_trdval(stock.getNet_trdval());
	    bhavCopyData.setNet_trdqty(stock.getNet_trdqty());
	    bhavCopyData.setCorp_ind(stock.getCorp_ind());
	    bhavCopyData.setHi_52_wk(stock.getHi_52_wk());
	    bhavCopyData.setLo_52_wk(stock.getLo_52_wk());
	    bhavCopyData.setChangePercent(stock.getChangePercent());
	    
	    
	    
	    return bhavCopyData;
	}

	
	
	
	public static void displaySearchResults(List<BhavCopyData> searchResults,BorderPane root) {
	    
		if(searchResults.isEmpty()) {
			root.setCenter(null);
		}
		
		VBox searchResultsContainer = new VBox();
	    TableView<BhavCopyData> tableView = new TableView<>();
	    
	    // Create table columns for each field in BhavCopyData
	    TableColumn<BhavCopyData, String> symbolColumn = new TableColumn<>("Symbol");
	    symbolColumn.setCellValueFactory(new PropertyValueFactory<>("symbol"));
	    
	    TableColumn<BhavCopyData, String> marketColumn = new TableColumn<>("Market");
	    marketColumn.setCellValueFactory(new PropertyValueFactory<>("market"));
	    
	    TableColumn<BhavCopyData, String> seriesColumn = new TableColumn<>("Series");
	    seriesColumn.setCellValueFactory(new PropertyValueFactory<>("series"));
	    
	    TableColumn<BhavCopyData, String> securityColumn = new TableColumn<>("Security");
	    securityColumn.setCellValueFactory(new PropertyValueFactory<>("security"));
	    
	    TableColumn<BhavCopyData, Double> prevCloseColumn = new TableColumn<>("Prev Close");
	    prevCloseColumn.setCellValueFactory(new PropertyValueFactory<>("prev_cl_pr"));
	    
	    TableColumn<BhavCopyData, Double> openColumn = new TableColumn<>("Open");
	    openColumn.setCellValueFactory(new PropertyValueFactory<>("open_price"));
	    
	    TableColumn<BhavCopyData, Double> highPriceColumn = new TableColumn<>("High_Price");
	    highPriceColumn.setCellValueFactory(new PropertyValueFactory<>("high_price"));
	    
	    
	    TableColumn<BhavCopyData, Double> lowPriceColumn = new TableColumn<>("Low_Price");
	    lowPriceColumn.setCellValueFactory(new PropertyValueFactory<>("low_price"));
	    
	    TableColumn<BhavCopyData, Double> closePriceColumn = new TableColumn<>("Close_Price");
	    closePriceColumn.setCellValueFactory(new PropertyValueFactory<>("close_price"));
	    
	    TableColumn<BhavCopyData, Double> netTrdColumn = new TableColumn<>("NET_TRD");
	    netTrdColumn.setCellValueFactory(new PropertyValueFactory<>("net_trdval"));
	    
	    TableColumn<BhavCopyData, Double> netQtyColumn = new TableColumn<>("NET_TRDQTY");
	    netQtyColumn.setCellValueFactory(new PropertyValueFactory<>("net_trdqty"));
	    
	    TableColumn<BhavCopyData, Double> corpIndColumn = new TableColumn<>("CORP_IND");
	    corpIndColumn.setCellValueFactory(new PropertyValueFactory<>("corp_ind"));
	    
	    TableColumn<BhavCopyData, Double> hiWkColumn = new TableColumn<>("HI_52_WK");
	    hiWkColumn.setCellValueFactory(new PropertyValueFactory<>("hi_52_wk"));
	    
	    TableColumn<BhavCopyData, Double> loWkColumn = new TableColumn<>("LO_52_WK");
	    loWkColumn.setCellValueFactory(new PropertyValueFactory<>("lo_52_wk"));
	    
	    TableColumn<BhavCopyData, Double> dateColumn = new TableColumn<>("Inserted_On");
	    dateColumn.setCellValueFactory(new PropertyValueFactory<>("insertion_date"));
	    
	    TableColumn<BhavCopyData, Double> changeColumn = new TableColumn<>("Change%");
	    changeColumn.setCellValueFactory(new PropertyValueFactory<>("changePercent"));

	    // Add the columns to the table view
	    tableView.getColumns().addAll(symbolColumn, marketColumn, seriesColumn, securityColumn, prevCloseColumn, openColumn,highPriceColumn,lowPriceColumn,closePriceColumn,netTrdColumn,netQtyColumn,corpIndColumn,hiWkColumn,loWkColumn,dateColumn,changeColumn);
	    
	    // Add the search results to the table view
	    tableView.getItems().addAll(searchResults);

	    tableView.prefHeightProperty().bind(searchResultsContainer.heightProperty());

	    tableView.prefWidthProperty().bind(searchResultsContainer.widthProperty());

	    tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
	    // Add the table view to the search results container
	    searchResultsContainer.getChildren().add(tableView);

	    root.setCenter(searchResultsContainer);
	}
	 
	 }
