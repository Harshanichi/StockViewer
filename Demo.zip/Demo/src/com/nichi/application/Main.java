package com.nichi.application;
	
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.util.Random;

import com.nichi.database.DataManager;
import com.nichi.registerandlogin.RegisterLogin;

//import com.nichi.registerandlogin.RegisterLogin;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Main extends Application {
	public static FXMLLoader loader;
	public static BorderPane root;
	@Override
	public void start(Stage primaryStage) {
		
		 Random r = new Random();
		 System.out.println(r.nextInt(100));
		
		try {
			
            loader = new FXMLLoader(Navigation.class.getResource("Sample.fxml"));
            root = loader.load();            
           Scene scene = new Scene(root, 800, 600);
           scene.getStylesheets().add(Navigation.class.getResource("application.css").toExternalForm());          
           primaryStage.setScene(scene);
           primaryStage.setTitle("Stock Viewer");
           primaryStage.getIcons().add(new Image(Navigation.class.getResourceAsStream("logo.png")));
           
           HostServices host = getHostServices();
           
           MenuBar bar = new MenuBar();
   		Menu menu = new Menu("Register");
   		MenuItem itemMenu = new MenuItem("Login");
   		MenuItem register = new MenuItem("Register");
   		menu.getItems().addAll(itemMenu,register);
   		bar.getMenus().add(menu);
   		
   		StackPane contentPane = new StackPane();
   		
   		itemMenu.setOnAction(e->{
   			RegisterLogin.login(primaryStage,root,scene,bar,contentPane,host);
   		});
   		
   		register.setOnAction(e->{
   			RegisterLogin.register(primaryStage,root,scene,bar);
   		});
   	 // Heading
        Text heading = new Text("About Stock Viewer");	
        heading.getStyleClass().add("heading");
       

        // Information
        Text informationText = new Text("Welcome to Stock Viewer! "
                + "The Stock Viewer application is a versatile tool designed to provide users with comprehensive insights into stock market data. "
                + "Developed with JavaFX, this application offers a user-friendly interface for accessing real-time and historical stock information, "
                + "facilitating informed investment decisions and market analysis. "
                + "With the ever-changing dynamics of the stock market, investors and traders require efficient and reliable means to track stock performance and identify potential opportunities. "
                + "The Stock Viewer application aims to address this need by offering a range of features tailored to suit the requirements of both novice and experienced users alike.");
        informationText.getStyleClass().add("information");
        
        StackPane headingPane = new StackPane(heading);
        headingPane.getStyleClass().add("heading-pane");
        informationText.setWrappingWidth(600); // Set the width for text wrapping
        StackPane informationPane = new StackPane(informationText);
        informationPane.getStyleClass().add("information-pane");
        
        
        contentPane.getChildren().addAll(headingPane,informationPane);
        root.setCenter(contentPane);


        //root.setCenter(new StackPane(headingPane,informationPane));
        root.setTop(bar);
           
           
           
//           Navigation.navBar(primaryStage,root,scene);
   		primaryStage.setScene(scene);
        primaryStage.show();
		} catch (Exception e) {
            e.printStackTrace();
        }
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
