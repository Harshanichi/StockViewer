package com.nichi.feedback;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailSender {

    public static void sendEmail(String recipientEmail, String subject, String content) {
        // Email server properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587"); // or your SMTP port
        properties.put("mail.smtp.auth", "true"); // enable authentication
        properties.put("mail.smtp.starttls.enable", "true"); // enable TLS encryption

        // Sender's credentials
        final String senderEmail = "harshanichi620@gmail.com";
        final String senderPassword = "ukwl damm cumb cmos";

        // Create a session with authentication
        Session session = Session.getInstance(properties, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            // Create a MimeMessage object
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject(subject);
            message.setText(content);

            // Send the message
            Transport.send(message);
            System.out.println("Email sent successfully to " + recipientEmail);
        } catch (MessagingException e) {
            e.printStackTrace();
            System.err.println("Failed to send email: " + e.getMessage());
        }
    }



    public static void sendFeedbackEmail(String recipientEmail, String name, String feedback) {
        // Send feedback email to admin
        String adminSubject = "New Feedback Received";
        String adminContent = "New feedback has been received from " + name + ".\nFeedback: " + feedback;
        sendEmail("harshanichi620@gmail.com", adminSubject, adminContent);

        // Send thank you email to user
        String userSubject = "Thank You for Your Feedback";
        String userContent = "Dear " + name + ",\n\nThank you for providing your feedback. We appreciate your input!";
        sendEmail(recipientEmail, userSubject, userContent);
    }
}
