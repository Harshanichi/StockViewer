package com.nichi.feedback;

import com.nichi.database.DataManager;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Feedback {

	public static void getFeedback(Stage primaryStage, BorderPane root, Scene scene,MenuBar menuBar) {
		
		scene.getStylesheets().add(Feedback.class.getResource("/com/nichi/application/application.css").toExternalForm());
		
		root.setTop(menuBar);
		root.setCenter(null);
		root.setRight(null);
		root.setBottom(null);
		
		Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();

        Label emailLabel = new Label("Email:");
        TextField emailField = new TextField();

        Label phoneLabel = new Label("Phone Number:");
        TextField phoneField = new TextField();

        Label commentsLabel = new Label("Comments:");
        TextArea commentsArea = new TextArea();

        Button submitButton = new Button("Submit");
        
        Label resultLabel = new Label();

        // Create a grid pane to organize the form
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(20));
        grid.setVgap(10);
        grid.setHgap(10);

        // Add form components to the grid
        grid.add(nameLabel, 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(emailLabel, 0, 1);
        grid.add(emailField, 1, 1);
        grid.add(phoneLabel, 0, 2);
        grid.add(phoneField, 1, 2);
        grid.add(commentsLabel, 0, 3);
        grid.add(commentsArea, 1, 3);
        grid.add(submitButton, 1, 4);

        // Create a VBox to hold the grid and add spacing
        VBox vbox = new VBox(grid);
        vbox.setSpacing(10);
        vbox.getChildren().addAll(resultLabel);
        
        root.setCenter(vbox);
        primaryStage.setScene(scene);
        primaryStage.show();
        
        
        submitButton.setOnAction(event -> {
            // Retrieve user input
            String name = nameField.getText();
            String email = emailField.getText();
            String phone = phoneField.getText();
            String comments = commentsArea.getText();
            
           
            DataManager.storeFeedback(name,email,phone,comments);
           
          
            System.out.println("Name: "+name+" email: "+email+" phone: "+phone+" Comments: "+comments);
            resultLabel.getStyleClass().add("success");
    		resultLabel.setText("Thanks for the Feedback "+name.toUpperCase());
    		EmailSender.sendFeedbackEmail(email, name, comments);

            // Clear form fields after submission
            nameField.clear();
            emailField.clear();
            phoneField.clear();
            commentsArea.clear();
            
        });    
        
		
	}

}
