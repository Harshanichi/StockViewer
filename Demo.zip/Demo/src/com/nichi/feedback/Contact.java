package com.nichi.feedback;

import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

import java.io.InputStream;

public class Contact {

    public static void getContact(Stage primaryStage, BorderPane root, Scene scene, MenuBar menuBar) {
        Label nameLabel = createLabel("Harsha G", Color.WHITE, FontWeight.BOLD, 18);
        Label addressLabel = createLabel("Bengaluru", Color.LIGHTGRAY, FontWeight.NORMAL, 14);

        // Load the email icon image
        Image emailImage = new Image(Contact.class.getResourceAsStream("/com/nichi/feedback/email_icon.jpg")); // Adjust the file path as needed
        ImageView emailIcon = new ImageView(emailImage);
        emailIcon.setFitHeight(20); // Set the height of the image icon
        emailIcon.setPreserveRatio(true); // Maintain aspect ratio

        // Create a label for the email address
        Label emailLabel = createLabel("harshanichi620@gmail.com", Color.LIGHTGRAY, FontWeight.NORMAL, 14);

        // Create an HBox to hold the email icon and label
        HBox emailBox = new HBox(5);
        emailBox.setAlignment(Pos.CENTER_LEFT);
        emailBox.getChildren().addAll(emailIcon, emailLabel);

        // Add a mouse event handler to open the default email client when clicking on the email label
        emailBox.setOnMouseClicked(event -> {
            // Open the default email client with the recipient's email address pre-filled
            String recipientEmail = emailLabel.getText();
            Platform.runLater(() -> {
                try {
                    java.awt.Desktop.getDesktop().mail(new java.net.URI("mailto:" + recipientEmail));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
        });

        // Create a VBox to stack the labels vertically
        VBox vbox = new VBox(10); // Set spacing between labels
        vbox.setAlignment(Pos.CENTER); // Center align the labels
        vbox.getChildren().addAll(nameLabel, addressLabel, emailBox); // Add the email box instead of email label

        // Create a rectangle as background with gradient effect
        Rectangle background = new Rectangle(300, 150);
        background.setFill(new LinearGradient(0, 0, 1, 1, true, null,
                new Stop(0, Color.DODGERBLUE),
                new Stop(1, Color.DARKSLATEBLUE)));
        background.setArcWidth(20);
        background.setArcHeight(20);
        background.setEffect(new DropShadow(10, Color.BLACK)); // Add drop shadow effect

        
       
        // Create a stack pane to overlay the background and VBox
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(background, vbox);
        stackPane.setPadding(new Insets(20));

        // Set the contact information in the center of the BorderPane
        root.setCenter(stackPane);

        // Set the scene and show the stage
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Utility method to create styled labels
    private static Label createLabel(String text, Color color, FontWeight weight, double size) {
        Label label = new Label(text);
        label.setFont(Font.font("Arial", weight, size));
        label.setTextFill(color);
        return label;
    }
}
