package com.nichi.overview;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import com.nichi.database.DataBaseManager;
import com.nichi.model.BhavCopyData;
import com.nichi.model.TableRowData;

public class SymbolGraph {
    
    public static void plotGraph(BhavCopyData data,BorderPane root,Scene overviewScene,Stage stage) {
        
    	root.getStyleClass().add(SymbolGraph.class.getResource("/com/nichi/application/application.css").toExternalForm());
    	
    	// Create sample data (insertion dates and close prices)
        List<Date> insertionDates = null;
        List<Double> closePrices=null;
		try {
			insertionDates = DataBaseManager.fetchInsertionDates(data.getSymbol());
			closePrices = DataBaseManager.fetchClosePrices(data.getSymbol());
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

        // Create a line chart with NumberAxis for X and Y axes
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
       
        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);

        // Set labels for the axes
        xAxis.setLabel("Insertion Date");
        yAxis.setLabel("Close Price");

        // Create a series for the data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Close Prices");

        System.out.println("Date size: "+insertionDates.size());
        // Add data points to the series
        for (int i = 0; i < insertionDates.size(); i++) {
        	Date sqlDate = insertionDates.get(i); // SQL Date object
            
        	String date = sqlDate.toLocalDate().toString()
;            System.out.println("This is the dates printing in the grap "+sqlDate.toLocalDate().toString());
            System.out.println("This one is the issue "+sqlDate.toLocalDate().toString());
            series.getData().add(new XYChart.Data<>(sqlDate.toLocalDate().toString(), closePrices.get(i)));
        }

        // Add the series to the line chart
        lineChart.getData().add(series);
        //lineChart.setPrefHeight(50);
      // lineChart.setPrefSize(500, 300);
        
        lineChart.getStyleClass().add("line-chart");        
        
        BorderPane graphPane = new BorderPane();
        graphPane.setCenter(lineChart);
       // root.setCenter(lineChart);
        //root.setRight(null);
        root.setCenter(graphPane);
        stage.setScene(overviewScene);
        stage.show();
       
    }

    
    
public static void plotGraph(TableRowData data,BorderPane root,Scene overviewScene,Stage stage) {
        
    	root.getStyleClass().add(SymbolGraph.class.getResource("/com/nichi/application/application.css").toExternalForm());
    	
    	// Create sample data (insertion dates and close prices)
        List<Date> insertionDates = null;
        List<Double> closePrices=null;
        
		try {
			insertionDates = DataBaseManager.fetchInsertionDates(data.getSymbol());
			closePrices = DataBaseManager.fetchClosePrices(data.getSymbol());
			
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        

        // Create a line chart with NumberAxis for X and Y axes
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
       
        LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);

        // Set labels for the axes
        xAxis.setLabel("Insertion Date");
        yAxis.setLabel("Close Price");
        

        // Create a series for the data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Close Prices");

        System.out.println("Date size: "+insertionDates.size());
        // Add data points to the series
        for (int i = 0; i < insertionDates.size(); i++) {
        	Date sqlDate = insertionDates.get(i); // SQL Date object
            
        	String date = sqlDate.toLocalDate().toString()
;            System.out.println("This is the dates printing in the grap "+sqlDate.toLocalDate().toString());
            System.out.println("This one is the issue "+sqlDate.toLocalDate().toString());
            series.getData().add(new XYChart.Data<>(sqlDate.toLocalDate().toString(), closePrices.get(i)));
        }

        // Add the series to the line chart
        lineChart.getData().add(series);
        //lineChart.setPrefHeight(50);
      // lineChart.setPrefSize(500, 300);
        
        lineChart.getStyleClass().add("line-chart");        
        
        BorderPane graphPane = new BorderPane();
        graphPane.setCenter(lineChart);
       // root.setCenter(lineChart);
        //root.setRight(null);
        root.setCenter(graphPane);
        stage.setScene(overviewScene);
        stage.show();
       
    }



public static void plotGraphVolume(TableRowData data,BorderPane root,Scene overviewScene,Stage stage) {
    
	root.getStyleClass().add(SymbolGraph.class.getResource("/com/nichi/application/application.css").toExternalForm());
	
	// Create sample data (insertion dates and close prices)
    List<Date> insertionDates = null;
    List<Double> volume=null;
    
	try {
		insertionDates = DataBaseManager.fetchInsertionDates(data.getSymbol());
		volume = DataBaseManager.fetchVolumeChange(data.getSymbol());
		
		 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    

    // Create a line chart with NumberAxis for X and Y axes
    CategoryAxis xAxis = new CategoryAxis();
    NumberAxis yAxis = new NumberAxis();
   
    LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);

    // Set labels for the axes
    xAxis.setLabel("Insertion Date");
    yAxis.setLabel("Volume Change");
    

    // Create a series for the data
    XYChart.Series<String, Number> series = new XYChart.Series<>();
    series.setName("Volume Change");

    System.out.println("Date size: "+insertionDates.size());
    // Add data points to the series
    for (int i = 0; i < insertionDates.size(); i++) {
    	Date sqlDate = insertionDates.get(i); // SQL Date object
        
    	String date = sqlDate.toLocalDate().toString()
;            System.out.println("This is the dates printing in the grap "+sqlDate.toLocalDate().toString());
        System.out.println("This one is the issue "+sqlDate.toLocalDate().toString());
        series.getData().add(new XYChart.Data<>(sqlDate.toLocalDate().toString(), volume.get(i)));
    }

    // Add the series to the line chart
    lineChart.getData().add(series);
    //lineChart.setPrefHeight(50);
  // lineChart.setPrefSize(500, 300);
    
    lineChart.getStyleClass().add("line-chart");        
    
    BorderPane graphPane = new BorderPane();
    graphPane.setCenter(lineChart);
   // root.setCenter(lineChart);
    //root.setRight(null);
    root.setCenter(graphPane);
    stage.setScene(overviewScene);
    stage.show();
   
}





public static void plotHomeGraph(ObservableList<BhavCopyData> gainer_data, ObservableList<BhavCopyData> looser_data,ObservableList<TableRowData> volume_data, BorderPane root, Scene scene, Stage primaryStage) {
	scene.getStylesheets().add(SymbolGraph.class.getResource("/com/nichi/application/application.css").toExternalForm());
	root.setCenter(null);
	// Create bar charts for gainers and losers
    BarChart<String, Number> gainerChart = createBarChart(gainer_data.subList(0, Math.min(5, gainer_data.size())), "Top 5 Gainers",true,scene);
    BarChart<String, Number> looserChart = createBarChart(looser_data.subList(0, Math.min(5, looser_data.size())), "Top 5 Losers",false,scene);
    BarChart<String, Number> volumeChart = createBarChartBuild(volume_data.subList(0, Math.min(5, looser_data.size())), "Top 5 Volume Gainers",false,scene);

    gainerChart.setLegendVisible(false);
    looserChart.setLegendVisible(false);
    volumeChart.setLegendVisible(false);
    
    
    // Add gainers and losers charts to VBox
    HBox chartsContainer = new HBox(gainerChart, looserChart);
    chartsContainer.setSpacing(10);
    
    VBox buildCharts = new VBox(volumeChart);
    buildCharts.setSpacing(10);
    
    VBox chart = new VBox(chartsContainer,buildCharts);
    chart.setSpacing(10);
   
    
    chart.getStyleClass().add("bar-chart");
    
   
    // Display the charts
    root.setCenter(chart);
}

private static BarChart<String, Number> createBarChart(List<BhavCopyData> dataList, String title,boolean isGainer,Scene scene) {
	scene.getStylesheets().add(SymbolGraph.class.getResource("/com/nichi/application/application.css").toExternalForm());
	// Create a bar chart
    CategoryAxis xAxis = new CategoryAxis();
    NumberAxis yAxis = new NumberAxis();
    
   
    BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
    // Set labels for the axes
    xAxis.setLabel("Symbol");
    yAxis.setLabel("Change Percent");
    barChart.getStyleClass().add("bar-chart");
    
    // Create data series for the data
    XYChart.Series<String, Number> series = new XYChart.Series<>();
    for (BhavCopyData data : dataList) {
        series.getData().add(new XYChart.Data<>(data.getSymbol(), data.getChangePercent()));
    }
    
    System.out.println(series.getData()+" this is after loop");
    // Add the series to the bar chart
    barChart.getData().add(series);
    
    
    for (XYChart.Data<String, Number> data : series.getData()) {
        Node node = data.getNode();
        System.out.println("This is the node "+node);
        if (isGainer) {
            node.getStyleClass().add("series0");
        } else {
            node.getStyleClass().add("series1");
        }
    }
    
    
    // Set chart title
    barChart.setTitle(title);
   

    return barChart;
}



private static BarChart<String, Number> createBarChartBuild(List<TableRowData> dataList, String title,boolean isGainer,Scene scene) {
    // Create a bar chart
    CategoryAxis xAxis = new CategoryAxis();
    NumberAxis yAxis = new NumberAxis();
    BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
    barChart.getStyleClass().add("bar-chart");
    barChart.setMaxHeight(18000);
    barChart.setMaxWidth(1000);
    // Set labels for the axes
    xAxis.setLabel("Symbol");
    yAxis.setLabel("Volume Change Percent");
    
    // Create data series for the data
    XYChart.Series<String, Number> series = new XYChart.Series<>();
    for (TableRowData data : dataList) {
        series.getData().add(new XYChart.Data<>(data.getSymbol(), data.getVolume()));
    }
    
    System.out.println(series.getData()+" this is after loop");
    // Add the series to the bar chart
    barChart.getData().add(series);
    
    
    
    
    
    
    // Set chart title
    barChart.setTitle(title);
   

    return barChart;
}


   
}
