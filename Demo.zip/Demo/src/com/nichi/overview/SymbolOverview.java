package com.nichi.overview;

import java.io.IOException;
import java.sql.Date;
import java.util.List;

import com.nichi.database.DataManager;
import com.nichi.model.BhavCopyData;
import com.nichi.model.TableRowData;
import com.nichi.sharing.Share;
import com.nichi.wishlist.Stock;
import com.nichi.wishlist.WishlistManager;

import javafx.application.Application;
import javafx.application.HostServices;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SymbolOverview {

	
	public static void displayOverview(BhavCopyData data,BorderPane root,Scene overviewScene,Stage stage,TableView table,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {

		
		
		// Create labels or other UI components to display detailed information about the selected symbol
		Label symbolLabel = new Label("Symbol: " + data.getSymbol());
		symbolLabel.getStyleClass().add("overview-label");
		
		Label marketLabel = new Label("Market: "+data.getMarket());
		marketLabel.getStyleClass().add("overview-label");
		System.out.println(data.getMarket()+" is this printing nothing?");
		
		Label seriesLabel = new Label("Series: "+data.getSeries());
		seriesLabel.getStyleClass().add("overview-label");
		
		Label securityLabel = new Label("Security: " + data.getSecurity());
		securityLabel.getStyleClass().add("overview-label");
		
		Label prev_cl_Label = new Label("Previous Closing Price: "+data.getPrev_cl_pr());
		prev_cl_Label.getStyleClass().add("overview-label");
		
		Label openLabel = new Label("Open Price: "+data.getOpen_price());
		openLabel.getStyleClass().add("overview-label");
		
		Label highLabel = new Label("High Price: "+data.getHigh_price());
		highLabel.getStyleClass().add("overview-label");
		
		Label lowLabel = new Label("Low Price: "+data.getLow_price());
		lowLabel.getStyleClass().add("overview-label");
		
		Label priceLabel = new Label("Close Price: "+data.getClose_price());
		priceLabel.getStyleClass().add("overview-label");
		
		Label nettrdValLabel = new Label("NET_TRDVAL: "+data.getNet_trdval());
		nettrdValLabel.getStyleClass().add("overview-label");
		
		Label nettrdQtyLabel = new Label("NET_TRDQTY: "+data.getNet_trdqty());
		nettrdQtyLabel.getStyleClass().add("overview-label");
		
		Label corpLabel = new Label("CORP_IND: "+data.getCorp_ind());
		corpLabel.getStyleClass().add("overview-label");
		
		Label high52Label = new Label("HI_52_WK: "+data.getHi_52_wk());
		high52Label.getStyleClass().add("overview-label");
		
		Label low52Label = new Label("LO_52_WK: "+data.getLo_52_wk());
		low52Label.getStyleClass().add("overview-label");
		
		Label change_priceLabel = new Label("Change%: "+data.getChangePercent());
		change_priceLabel.getStyleClass().add("overview-label");
		// Add more labels for other fields as needed
   
		
		VBox sym = new VBox(symbolLabel);
		VBox mark = new VBox(marketLabel);
		VBox series = new VBox(seriesLabel);
		VBox secure = new VBox(securityLabel);
		VBox prev = new VBox(prev_cl_Label);
		VBox open = new VBox(openLabel);
		VBox high = new VBox(highLabel);

		VBox topLine = new VBox(sym, mark, series, secure, prev, open, high);
		topLine.setSpacing(10);
		topLine.getStyleClass().add("overview-line");

		// overviewPane.setRight(topLine);
		// Scene overviewScene = new Scene(root, 400, 300);
		overviewScene.getStylesheets().add(SymbolOverview.class.getResource("/com/nichi/application/application.css").toExternalForm());

		VBox low = new VBox(lowLabel);
		VBox price = new VBox(priceLabel);
		VBox nettrd = new VBox(nettrdValLabel);
		VBox nettrdqty = new VBox(nettrdQtyLabel);
		VBox corp = new VBox(corpLabel);
		VBox hi52 = new VBox(high52Label);
		VBox lo52 = new VBox(low52Label);
		VBox change = new VBox(change_priceLabel);
		Button wish = new Button("\u2764 WishList");
		wish.getStyleClass().add("wishlist-button");
		 Label statusLabel = new Label();
		 
		

		 
		 
		 wish.setOnAction(e -> {
			    System.out.println("Clicked wishlist");

			    BhavCopyData selectedData = data;

			    // Extract relevant information from selectedData
			    String symbol = selectedData.getSymbol();
			    String name = selectedData.getSecurity();

			    // Create a new Stock object
			    Stock selectedStock = new Stock(symbol, name);

			    // Check if the selectedStock is already in the wishlist
			    WishlistManager wishlistManager = WishlistManager.getInstance();
			    List<Object> wishlistData = wishlistManager.getWishlistData(userId);
			    boolean alreadyExists = false;
			    for (Object item : wishlistData) {
			        if (item instanceof Stock) {
			            Stock stockItem = (Stock) item;
			            if (stockItem.getSymbol().equals(symbol)) {
			                alreadyExists = true;
			                break;
			            }
			        }
			    }

			    if (alreadyExists) {
			        statusLabel.setText("Stock already in wishlist");
			    } else {
			        // Add the selectedStock to the wishlist
			        wishlistManager.addToWishlist(userId, selectedStock);
			        statusLabel.setText("Added to wishlist successfully");
			    }
			});


		VBox secLine = new VBox(low, price, nettrd, nettrdqty, corp, hi52, lo52, change,wish,statusLabel);
		secLine.setSpacing(10);
		secLine.getStyleClass().add("overview-line");
		VBox detail = new VBox(topLine, secLine);
		detail.setSpacing(10);

		

		
		// Create a ScrollPane and set the content to the detail VBox
		ScrollPane scrollPane = new ScrollPane(root);
		scrollPane.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
		scrollPane.setFitToHeight(true); // Allow the ScrollPane to resize vertically

		// Set the maximum width and height to allow the ScrollPane to expand
		scrollPane.setMaxWidth(Double.MAX_VALUE);
		scrollPane.setMaxHeight(Double.MAX_VALUE);

		
		root.setRight(detail);
		// Set the ScrollPane as the root center
		root.setCenter(scrollPane);

		
		
//		// Set the ScrollPane as the root of your layout
//		root.setCenter(scrollPane);
//		
//		
//		root.setRight(detail);
//   
   
   
   
   
   topLine.getStyleClass().add("overview-line");
   secLine.getStyleClass().add("overview-line");
  // detail.getStyleClass().add("overview-container");
   // Apply CSS styling to the overviewPane
   root.getStyleClass().add("overview-pane");
		
   SymbolGraph.plotGraph(data, root, overviewScene, stage);
   
   Button share = new Button("Share");
   share.setOnAction(e->{
	   System.out.println("Clicked on Share Button.");
	   System.out.println(data.toString()+"This is the message youre trying to send");
	   Share.share(stage, root, overviewScene, menuBar, host,data,menuAndButtons,DataManager.getNames());
   });
   
   Button goBackButton = new Button("Go Back");
   
   goBackButton.setOnAction(event -> {
       root.setRight(null);
       root.setBottom(null);
      root.setCenter(table);
   });
   
   HBox bottomBox = new HBox(share,goBackButton);
   root.setBottom(bottomBox);
   bottomBox.setAlignment(Pos.CENTER); // Align the button to the center
   bottomBox.getStyleClass().add("overview-line");

   // Create VBox to hold both the detailed information and the "Go Back" button
   VBox rootWithButton = new VBox( bottomBox);

   // Set the VBox to the center of the BorderPane
   root.setBottom(rootWithButton);
   	
		
   		stage.setScene(overviewScene);
   		stage.show();
   		
	    

	    
	}


public static void displayOverview(TableRowData data,BorderPane root,Scene overviewScene,Stage stage,TableView table,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {
		
		// Create labels or other UI components to display detailed information about the selected symbol
		Label symbolLabel = new Label("Symbol: " + data.getSymbol());
		symbolLabel.getStyleClass().add("overview-label");
		
		Label marketLabel = new Label("Market: "+data.getMarket());
		marketLabel.getStyleClass().add("overview-label");
		
		Label seriesLabel = new Label("Series: "+data.getSeries());
		seriesLabel.getStyleClass().add("overview-label");
		
		Label securityLabel = new Label("Security: " + data.getSecurity());
		securityLabel.getStyleClass().add("overview-label");
		
		Label prev_cl_Label = new Label("Previous Closing Price: "+data.getPrev_cl_pr());
		prev_cl_Label.getStyleClass().add("overview-label");
		
		Label openLabel = new Label("Open Price: "+data.getOpen_price());
		openLabel.getStyleClass().add("overview-label");
		
		Label highLabel = new Label("High Price: "+data.getHigh_price());
		highLabel.getStyleClass().add("overview-label");
		
		Label lowLabel = new Label("Low Price: "+data.getLow_price());
		lowLabel.getStyleClass().add("overview-label");
		
		Label priceLabel = new Label("Close Price: "+data.getClose_price());
		priceLabel.getStyleClass().add("overview-label");
		
		Label nettrdValLabel = new Label("NET_TRDVAL: "+data.getNet_trdval());
		nettrdValLabel.getStyleClass().add("overview-label");
		
		Label nettrdQtyLabel = new Label("NET_TRDQTY: "+data.getNet_trdqty());
		nettrdQtyLabel.getStyleClass().add("overview-label");
		
		Label corpLabel = new Label("CORP_IND: "+data.getCorp_ind());
		corpLabel.getStyleClass().add("overview-label");
		
		Label high52Label = new Label("HI_52_WK: "+data.getHi_52_wk());
		high52Label.getStyleClass().add("overview-label");
		
		Label low52Label = new Label("LO_52_WK: "+data.getLo_52_wk());
		low52Label.getStyleClass().add("overview-label");
		
		
		Label change_priceLabel = change_priceLabel = new Label("Long BuildUp: "+data.getLongBuildup());;
		change_priceLabel.getStyleClass().add("overview-label");
		
		
		// Add more labels for other fields as needed
		Label short_priceLabel=short_priceLabel = new Label("Short BuildUp: "+data.getShortBuildup());
		short_priceLabel.getStyleClass().add("overview-label");
		
		Label vol = new Label("Volume Change: "+data.getVolume());
		vol.getStyleClass().add("overview-vol");
		System.out.println(data.getVolume());
	
		VBox sym = new VBox(symbolLabel);
		VBox mark = new VBox(marketLabel);
		VBox series = new VBox(seriesLabel);
		VBox secure = new VBox(securityLabel);
		VBox prev = new VBox(prev_cl_Label);
		VBox open = new VBox(openLabel);
		VBox high = new VBox(highLabel);

		VBox topLine = new VBox(sym, mark, series, secure, prev, open, high);
		topLine.setSpacing(10);
		topLine.getStyleClass().add("overview-line");

		// overviewPane.setRight(topLine);
		// Scene overviewScene = new Scene(root, 400, 300);
		overviewScene.getStylesheets().add(SymbolOverview.class.getResource("/com/nichi/application/application.css").toExternalForm());

		VBox low = new VBox(lowLabel);
		VBox price = new VBox(priceLabel);
		VBox nettrd = new VBox(nettrdValLabel);
		VBox nettrdqty = new VBox(nettrdQtyLabel);
		VBox corp = new VBox(corpLabel);
		VBox hi52 = new VBox(high52Label);
		VBox lo52 = new VBox(low52Label);
		VBox change = new VBox(change_priceLabel);
		VBox shortBP = new VBox(short_priceLabel);
		VBox volB = new VBox(vol);
		Button wish = new Button("\u2764 WishList");
		wish.getStyleClass().add("wishlist-button");
		
		 Label statusLabel = new Label();
		
		
		
		 wish.setOnAction(e -> {
			    System.out.println("Clicked wishlist");

			    TableRowData selectedData = data;

			    // Extract relevant information from selectedData
			    String symbol = selectedData.getSymbol();
			    String name = selectedData.getSecurity();

			    // Create a new Stock object
			    Stock selectedStock = new Stock(symbol, name);

			    // Check if the selectedStock is already in the wishlist
			    WishlistManager wishlistManager = WishlistManager.getInstance();
			    List<Object> wishlistData = wishlistManager.getWishlistData(userId);
			    boolean alreadyExists = false;
			    for (Object item : wishlistData) {
			        if (item instanceof Stock) {
			            Stock stockItem = (Stock) item;
			            if (stockItem.getSymbol().equals(symbol)) {
			                alreadyExists = true;
			                break;
			            }
			        }
			    }

			    if (alreadyExists) {
			        statusLabel.setText("Stock already in wishlist");
			    } else {
			        // Add the selectedStock to the wishlist
			        wishlistManager.addToWishlist(userId, selectedStock);
			        statusLabel.setText("Added to wishlist successfully");
			    }
			});
		

		VBox secLine = new VBox(low, price, nettrd, nettrdqty, corp, hi52, lo52, change,shortBP,volB,wish,statusLabel);
		secLine.setSpacing(10);
		secLine.getStyleClass().add("overview-line");
		VBox detail = new VBox(topLine, secLine);
		detail.setSpacing(10);

		
		ScrollPane scrollPane = new ScrollPane(detail);
		scrollPane.setFitToWidth(true);
		scrollPane.setFitToHeight(true);

		// Set the ScrollPane as the root of your layout
		root.setCenter(scrollPane);
		
		
   root.setRight(detail);
   
   
   
   
   
   topLine.getStyleClass().add("overview-line");
   secLine.getStyleClass().add("overview-line");
  // detail.getStyleClass().add("overview-container");
   // Apply CSS styling to the overviewPane
   root.getStyleClass().add("overview-pane");
		
   SymbolGraph.plotGraph(data, root, overviewScene, stage);
   
   Button goBackButton = new Button("Go Back");
   
   goBackButton.setOnAction(event -> {
       root.setRight(null);
       root.setBottom(null);
      root.setCenter(table);
   });
   
 Button share = new Button("Share");
 share.setOnAction(e->{
	 System.out.println("Share Button Clicked.");
	 Share.share(stage, root, overviewScene, menuBar, host,data,menuAndButtons,DataManager.getNames());
	 
 });
   
   goBackButton.setOnAction(event -> {
       root.setRight(null);
       root.setBottom(null);
      root.setCenter(table);
   });
   
   HBox bottomBox = new HBox(share,goBackButton);
   root.setBottom(bottomBox);
   bottomBox.setAlignment(Pos.CENTER); // Align the button to the center
   bottomBox.getStyleClass().add("overview-line");
   
   


   // Create VBox to hold both the detailed information and the "Go Back" button
   VBox rootWithButton = new VBox( bottomBox);

   // Set the VBox to the center of the BorderPane
   root.setBottom(rootWithButton);
   	
		
   		stage.setScene(overviewScene);
   		stage.show();
   		
	    

	    
	}






public static void displayOverview(BhavCopyData data,BorderPane root,Scene overviewScene,Stage stage,ScrollPane scroll,MenuBar menuBar,HostServices host,VBox menuAndButtons,String userId) {

	
	
	// Create labels or other UI components to display detailed information about the selected symbol
	Label symbolLabel = new Label("Symbol: " + data.getSymbol());
	symbolLabel.getStyleClass().add("overview-label");
	
	Label marketLabel = new Label("Market: "+data.getMarket());
	marketLabel.getStyleClass().add("overview-label");
	System.out.println(data.getMarket()+" is this printing nothing?");
	
	Label seriesLabel = new Label("Series: "+data.getSeries());
	seriesLabel.getStyleClass().add("overview-label");
	
	Label securityLabel = new Label("Security: " + data.getSecurity());
	securityLabel.getStyleClass().add("overview-label");
	
	Label prev_cl_Label = new Label("Previous Closing Price: "+data.getPrev_cl_pr());
	prev_cl_Label.getStyleClass().add("overview-label");
	
	Label openLabel = new Label("Open Price: "+data.getOpen_price());
	openLabel.getStyleClass().add("overview-label");
	
	Label highLabel = new Label("High Price: "+data.getHigh_price());
	highLabel.getStyleClass().add("overview-label");
	
	Label lowLabel = new Label("Low Price: "+data.getLow_price());
	lowLabel.getStyleClass().add("overview-label");
	
	Label priceLabel = new Label("Close Price: "+data.getClose_price());
	priceLabel.getStyleClass().add("overview-label");
	
	Label nettrdValLabel = new Label("NET_TRDVAL: "+data.getNet_trdval());
	nettrdValLabel.getStyleClass().add("overview-label");
	
	Label nettrdQtyLabel = new Label("NET_TRDQTY: "+data.getNet_trdqty());
	nettrdQtyLabel.getStyleClass().add("overview-label");
	
	Label corpLabel = new Label("CORP_IND: "+data.getCorp_ind());
	corpLabel.getStyleClass().add("overview-label");
	
	Label high52Label = new Label("HI_52_WK: "+data.getHi_52_wk());
	high52Label.getStyleClass().add("overview-label");
	
	Label low52Label = new Label("LO_52_WK: "+data.getLo_52_wk());
	low52Label.getStyleClass().add("overview-label");
	
	Label change_priceLabel = new Label("Change%: "+data.getChangePercent());
	change_priceLabel.getStyleClass().add("overview-label");
	// Add more labels for other fields as needed

	
	VBox sym = new VBox(symbolLabel);
	VBox mark = new VBox(marketLabel);
	VBox series = new VBox(seriesLabel);
	VBox secure = new VBox(securityLabel);
	VBox prev = new VBox(prev_cl_Label);
	VBox open = new VBox(openLabel);
	VBox high = new VBox(highLabel);

	VBox topLine = new VBox(sym, mark, series, secure, prev, open, high);
	topLine.setSpacing(10);
	topLine.getStyleClass().add("overview-line");

	// overviewPane.setRight(topLine);
	// Scene overviewScene = new Scene(root, 400, 300);
	overviewScene.getStylesheets().add(SymbolOverview.class.getResource("/com/nichi/application/application.css").toExternalForm());

	VBox low = new VBox(lowLabel);
	VBox price = new VBox(priceLabel);
	VBox nettrd = new VBox(nettrdValLabel);
	VBox nettrdqty = new VBox(nettrdQtyLabel);
	VBox corp = new VBox(corpLabel);
	VBox hi52 = new VBox(high52Label);
	VBox lo52 = new VBox(low52Label);
	VBox change = new VBox(change_priceLabel);
	
	 
	

	


	VBox secLine = new VBox(low, price, nettrd, nettrdqty, corp, hi52, lo52, change);
	secLine.setSpacing(10);
	secLine.getStyleClass().add("overview-line");
	VBox detail = new VBox(topLine, secLine);
	detail.setSpacing(10);

	

	
	// Create a ScrollPane and set the content to the detail VBox
	ScrollPane scrollPane = new ScrollPane(root);
	scrollPane.setFitToWidth(true); // Allow the ScrollPane to resize horizontally
	scrollPane.setFitToHeight(true); // Allow the ScrollPane to resize vertically

	// Set the maximum width and height to allow the ScrollPane to expand
	scrollPane.setMaxWidth(Double.MAX_VALUE);
	scrollPane.setMaxHeight(Double.MAX_VALUE);

	
	root.setRight(detail);
	// Set the ScrollPane as the root center
	root.setCenter(scrollPane);

	
	




topLine.getStyleClass().add("overview-line");
secLine.getStyleClass().add("overview-line");
// detail.getStyleClass().add("overview-container");
// Apply CSS styling to the overviewPane
root.getStyleClass().add("overview-pane");
	
SymbolGraph.plotGraph(data, root, overviewScene, stage);

Button share = new Button("Share");
share.setOnAction(e->{
   System.out.println("Clicked on Share Button.");
   System.out.println(data.toString()+"This is the message youre trying to send");
   Share.share(stage, root, overviewScene, menuBar, host,data,menuAndButtons,DataManager.getNames());
});

Button goBackButton = new Button("Go Back");

goBackButton.setOnAction(event -> {
   root.setRight(null);
   root.setBottom(null);
  root.setCenter(scroll);
});

HBox bottomBox = new HBox(share,goBackButton);
root.setBottom(bottomBox);
bottomBox.setAlignment(Pos.CENTER); // Align the button to the center
bottomBox.getStyleClass().add("overview-line");

// Create VBox to hold both the detailed information and the "Go Back" button
VBox rootWithButton = new VBox( bottomBox);

// Set the VBox to the center of the BorderPane
root.setBottom(rootWithButton);
	
	
		stage.setScene(overviewScene);
		stage.show();
		
    

    
}

	

}
