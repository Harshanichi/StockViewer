package com.nichi.model;

import java.sql.Date;

public class HighLowData {

	private String symbol;
	private String series;
	private double adjusted_52_week_high;
	private Date week_high_date;
	private double adjusted_52_week_low;
	private Date week_low_date;
	
	
	
	
	public HighLowData(String symbol, String series, double adjusted_52_week_high, Date week_high_date,
			double adjusted_52_week_low, Date week_low_date) {
		super();
		this.symbol = symbol;
		this.series = series;
		this.adjusted_52_week_high = adjusted_52_week_high;
		this.week_high_date = week_high_date;
		this.adjusted_52_week_low = adjusted_52_week_low;
		this.week_low_date = week_low_date;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public double getAdjusted_52_week_high() {
		return adjusted_52_week_high;
	}
	public void setAdjusted_52_week_high(double adjusted_52_week_high) {
		this.adjusted_52_week_high = adjusted_52_week_high;
	}
	public Date getWeek_high_date() {
		return week_high_date;
	}
	public void setWeek_high_date(Date week_high_date) {
		this.week_high_date = week_high_date;
	}
	public double getAdjusted_52_week_low() {
		return adjusted_52_week_low;
	}
	public void setAdjusted_52_week_low(double adjusted_52_week_low) {
		this.adjusted_52_week_low = adjusted_52_week_low;
	}
	public Date getWeek_low_date() {
		return week_low_date;
	}
	public void setWeek_low_date(Date week_low_date) {
		this.week_low_date = week_low_date;
	}


}
