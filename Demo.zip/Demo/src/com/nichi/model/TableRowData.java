package com.nichi.model;

public class TableRowData {
	
	private  String symbol;
    private double price;
    private double longBuildup;
    private double shortBuildup;
    private String insertionDate;
    private double volume;
    private double change_percent;
    private String market;
    private String series;
    private String security;
    private double prev_cl_pr;
    private double open_price;
    private double high_price;
    private double low_price;
    private double close_price;
    private double net_trdval;
    private int net_trdqty;
    private String corp_ind;
    private double hi_52_wk;
    private double lo_52_wk;
    
    
    
    
    
    
    
    
    
    
    
	
	public double getOpen_price() {
		return open_price;
	}
	public void setOpen_price(double open_price) {
		this.open_price = open_price;
	}
	public double getHigh_price() {
		return high_price;
	}
	public void setHigh_price(double high_price) {
		this.high_price = high_price;
	}
	public double getLow_price() {
		return low_price;
	}
	public void setLow_price(double low_price) {
		this.low_price = low_price;
	}
	public double getClose_price() {
		return close_price;
	}
	public void setClose_price(double close_price) {
		this.close_price = close_price;
	}
	public double getNet_trdval() {
		return net_trdval;
	}
	public void setNet_trdval(double net_trdval) {
		this.net_trdval = net_trdval;
	}
	public int getNet_trdqty() {
		return net_trdqty;
	}
	public void setNet_trdqty(int net_trdqty) {
		this.net_trdqty = net_trdqty;
	}
	public String getCorp_ind() {
		return corp_ind;
	}
	public void setCorp_ind(String corp_ind) {
		this.corp_ind = corp_ind;
	}
	public double getHi_52_wk() {
		return hi_52_wk;
	}
	public void setHi_52_wk(double hi_52_wk) {
		this.hi_52_wk = hi_52_wk;
	}
	public double getLo_52_wk() {
		return lo_52_wk;
	}
	public void setLo_52_wk(double lo_52_wk) {
		this.lo_52_wk = lo_52_wk;
	}
	public double getPrev_cl_pr() {
		return prev_cl_pr;
	}
	public void setPrev_cl_pr(double prev_cl_pr) {
		this.prev_cl_pr = prev_cl_pr;
	}
	public String getSecurity() {
		return security;
	}
	public void setSecurity(String security) {
		this.security = security;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public double getChange_percent() {
		return change_percent;
	}
	public void setChange_percent(double change_percent) {
		this.change_percent = change_percent;
	}
	public TableRowData(String symbol, double price, double volume, double change_percent,String market,String series,String security,double prev,double open_price,double high_price,
		     double low_price,double close_price,double net_trdval,int net_trdqty,String corp_ind,double hi_52_wk,double lo_52_wk) {
		super();
		this.symbol = symbol;
		this.price = price;
		this.volume = volume;
		this.change_percent= change_percent;
		this.market=market;
		this.series=series;
		this.security = security;
		this.prev_cl_pr=prev;
		this.open_price=open_price;
		this.high_price=high_price;
		this.low_price=low_price;
		this.close_price=close_price;
		this.net_trdval=net_trdval;
		this.net_trdqty=net_trdqty;
		this.corp_ind=corp_ind;
		this.hi_52_wk=hi_52_wk;
		this.lo_52_wk=lo_52_wk;
	}
	
	
	public String getMarket() {
		return market;
	}
	public void setMarket(String market) {
		this.market = market;
	}
	public double getVolume() {
		return volume;
	}
	public void setVolume(double volume) {
		this.volume = volume;
	}
	public TableRowData(double price,String symbol , double shortBuildup, String insertionDate,String market,String series,String security,double prev,double open_price,double high_price,
		     double low_price,double close_price,double net_trdval,int net_trdqty,String corp_ind,double hi_52_wk,double lo_52_wk) {
		super();
		this.symbol = symbol;
		this.price = price;
		this.shortBuildup = shortBuildup;
		this.insertionDate = insertionDate;
		this.market=market;
		this.series=series;
		this.security = security;
		this.prev_cl_pr=prev;
		this.open_price=open_price;
		this.high_price=high_price;
		this.low_price=low_price;
		this.close_price=close_price;
		this.net_trdval=net_trdval;
		this.net_trdqty=net_trdqty;
		this.corp_ind=corp_ind;
		this.hi_52_wk=hi_52_wk;
		this.lo_52_wk=lo_52_wk;
	}
	public TableRowData(String symbol, double price, double longBuildup, String insertionDate,String market,String series,String security,double prev,double open_price,double high_price,
     double low_price,double close_price,double net_trdval,int net_trdqty,String corp_ind,double hi_52_wk,double lo_52_wk) {
		super();
		this.symbol = symbol;
		this.price = price;
		this.longBuildup = longBuildup;
		this.insertionDate = insertionDate;
		this.market=market;
		this.series=series;
		this.security = security;
		this.prev_cl_pr=prev;
		this.open_price=open_price;
		this.high_price=high_price;
		this.low_price=low_price;
		this.close_price=close_price;
		this.net_trdval=net_trdval;
		this.net_trdqty=net_trdqty;
		this.corp_ind=corp_ind;
		this.hi_52_wk=hi_52_wk;
		this.lo_52_wk=lo_52_wk;
		
		
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getLongBuildup() {
		return longBuildup;
	}
	public void setLongBuildup(double longBuildup) {
		this.longBuildup = longBuildup;
	}
	public double getShortBuildup() {
		return shortBuildup;
	}
	public void setShortBuildup(double shortBuildup) {
		this.shortBuildup = shortBuildup;
	}
	public String getInsertionDate() {
		return insertionDate;
	}
	public void setInsertionDate(String insertionDate) {
		this.insertionDate = insertionDate;
	}
	@Override
	public String toString() {
		return "symbol=" + symbol + ", price=" + price + ", longBuildup=" + longBuildup
				+ ", shortBuildup=" + shortBuildup + ", insertionDate=" + insertionDate + ", volume=" + volume
				+ ", change_percent=" + change_percent + ", market=" + market + ", series=" + series + ", security="
				+ security + ", prev_cl_pr=" + prev_cl_pr + ", open_price=" + open_price + ", high_price=" + high_price
				+ ", low_price=" + low_price + ", close_price=" + close_price + ", net_trdval=" + net_trdval
				+ ", net_trdqty=" + net_trdqty + ", corp_ind=" + corp_ind + ", hi_52_wk=" + hi_52_wk + ", lo_52_wk="
				+ lo_52_wk;
	}
    
    
    
    
        }
