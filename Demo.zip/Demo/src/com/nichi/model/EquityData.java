package com.nichi.model;

import java.util.Date;

public class EquityData {
	private String symbol;
	private String name_of_company;
	private String series;
	private Date date_of_listing;
	private double paid_up_value;
	private int market_lot;
	private String isin_number;
	private double face_value;
	public EquityData(String symbol, String name_of_company, String series, Date date_of_listing, double paid_up_value,
			int market_lot, String isin_number, double face_value) {
		
		this.symbol = symbol;
		this.name_of_company = name_of_company;
		this.series = series;
		this.date_of_listing = date_of_listing;
		this.paid_up_value = paid_up_value;
		this.market_lot = market_lot;
		this.isin_number = isin_number;
		this.face_value = face_value;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getName_of_company() {
		return name_of_company;
	}
	public void setName_of_company(String name_of_company) {
		this.name_of_company = name_of_company;
	}
	public String getSeries() {
		return series;
	}
	public void setSeries(String series) {
		this.series = series;
	}
	public Date getDate_of_listing() {
		return date_of_listing;
	}
	public void setDate_of_listing(Date date_of_listing) {
		this.date_of_listing = date_of_listing;
	}
	public double getPaid_up_value() {
		return paid_up_value;
	}
	public void setPaid_up_value(double paid_up_value) {
		this.paid_up_value = paid_up_value;
	}
	public int getMarket_lot() {
		return market_lot;
	}
	public void setMarket_lot(int market_lot) {
		this.market_lot = market_lot;
	}
	public String getIsin_number() {
		return isin_number;
	}
	public void setIsin_number(String isin_number) {
		this.isin_number = isin_number;
	}
	public double getFace_value() {
		return face_value;
	}
	public void setFace_value(double face_value) {
		this.face_value = face_value;
	}
	
	
}
