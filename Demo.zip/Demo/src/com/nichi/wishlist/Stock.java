package com.nichi.wishlist;

import java.sql.Date;

public class Stock {
	private String symbol;
    private String name;
    // Add other attributes as needed
    
    
    private String market;
	private String series;
	private String security;
	private double prev_cl_pr;
	private double open_price;
	private double high_price;
	private double low_price;
	private double close_price;
	private double net_trdval;
	private int net_trdqty;
	private String corp_ind;
	private double hi_52_wk;
	private double lo_52_wk;
	private Date insertion_date;
	private double changePercent;
	private double pivot;
	
	
	

    public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public double getPrev_cl_pr() {
		return prev_cl_pr;
	}

	public void setPrev_cl_pr(double prev_cl_pr) {
		this.prev_cl_pr = prev_cl_pr;
	}

	public double getOpen_price() {
		return open_price;
	}

	public void setOpen_price(double open_price) {
		this.open_price = open_price;
	}

	public double getHigh_price() {
		return high_price;
	}

	public void setHigh_price(double high_price) {
		this.high_price = high_price;
	}

	public double getLow_price() {
		return low_price;
	}

	public void setLow_price(double low_price) {
		this.low_price = low_price;
	}

	public double getClose_price() {
		return close_price;
	}

	public void setClose_price(double close_price) {
		this.close_price = close_price;
	}

	public double getNet_trdval() {
		return net_trdval;
	}

	public void setNet_trdval(double net_trdval) {
		this.net_trdval = net_trdval;
	}

	public int getNet_trdqty() {
		return net_trdqty;
	}

	public void setNet_trdqty(int net_trdqty) {
		this.net_trdqty = net_trdqty;
	}

	public String getCorp_ind() {
		return corp_ind;
	}

	public void setCorp_ind(String corp_ind) {
		this.corp_ind = corp_ind;
	}

	public double getHi_52_wk() {
		return hi_52_wk;
	}

	public void setHi_52_wk(double hi_52_wk) {
		this.hi_52_wk = hi_52_wk;
	}

	public double getLo_52_wk() {
		return lo_52_wk;
	}

	public void setLo_52_wk(double lo_52_wk) {
		this.lo_52_wk = lo_52_wk;
	}

	public Date getInsertion_date() {
		return insertion_date;
	}

	public void setInsertion_date(Date insertion_date) {
		this.insertion_date = insertion_date;
	}

	public double getChangePercent() {
		return changePercent;
	}

	public void setChangePercent(double changePercent) {
		this.changePercent = changePercent;
	}

	public double getPivot() {
		return pivot;
	}

	public void setPivot(double pivot) {
		this.pivot = pivot;
	}

	public Stock(String symbol, String name) {
        this.symbol = symbol;
        this.name = name;
    }

    // Getters and setters
    
    @Override
    public String toString() {
        return "Symbol = "+symbol+" Name = "+name;
    }

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
