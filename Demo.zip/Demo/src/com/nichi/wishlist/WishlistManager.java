//package com.nichi.wishlist;
//
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//
//public class WishlistManager {
//    private static WishlistManager instance;
//    private Map<String, List<Object>> userWishlists;
//
//    // Private constructor to prevent instantiation
//    private WishlistManager() {
//        userWishlists = new HashMap<>();
//    }
//
//    // Method to add an item to the wishlist for a specific user
//    public void addToWishlist(String userId, Object data) {
//        // Get the wishlist for the specified user
//        List<Object> userWishlist = userWishlists.computeIfAbsent(userId, k -> new ArrayList<>());
//        // Add the item to the user's wishlist
//        userWishlist.add(data);
//    }
//
//    // Method to retrieve the wishlist data for a specific user
//    public List<Object> getWishlistData(String userId) {
//        // Get the wishlist for the specified user
//        List<Object> userWishlist = userWishlists.get(userId);
//        if (userWishlist == null) {
//            // If the user has no wishlist yet, return an empty list
//            return new ArrayList<>();
//        }
//        // Return the user's wishlist
//        return userWishlist;
//    }
//
//    // Singleton getInstance method
//    public static WishlistManager getInstance() {
//        if (instance == null) {
//            instance = new WishlistManager();
//        }
//        return instance;
//    }
//}

package com.nichi.wishlist;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WishlistManager {
    private static WishlistManager instance;
    private Map<String, List<Object>> userWishlists;

    // Private constructor to prevent instantiation
    private WishlistManager() {
        userWishlists = new HashMap<>();
    }

    // Method to add an item to the wishlist for a specific user
    public void addToWishlist(String userId, Object data) {
        // Get the wishlist for the specified user
        List<Object> userWishlist = userWishlists.computeIfAbsent(userId, k -> new ArrayList<>());
        // Add the item to the user's wishlist
        userWishlist.add(data);
    }

    // Method to retrieve the wishlist data for a specific user
    public List<Object> getWishlistData(String userId) {
        // Get the wishlist for the specified user
        List<Object> userWishlist = userWishlists.get(userId);
        if (userWishlist == null) {
            // If the user has no wishlist yet, return an empty list
            return new ArrayList<>();
        }
        // Return the user's wishlist
        return userWishlist;
    }

    // Method to remove an item from the wishlist for a specific user
    public void removeFromWishlist(String userId, Object data) {
        // Get the wishlist for the specified user
        List<Object> userWishlist = userWishlists.get(userId);
        if (userWishlist != null) {
            // Remove the item from the user's wishlist
            userWishlist.remove(data);
        }
    }

    // Singleton getInstance method
    public static WishlistManager getInstance() {
        if (instance == null) {
            instance = new WishlistManager();
        }
        return instance;
    }

	
	
    

    
    
    
}
