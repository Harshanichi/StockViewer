module Demo {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.sql;
    requires javafx.base;
    requires java.mail;
    requires java.desktop;
    requires javafx.swing;
	requires Stock;
	requires org.jsoup;
	


    opens com.nichi.model to javafx.base;
    opens com.nichi.application to javafx.graphics, javafx.fxml, javafx.base;
}
