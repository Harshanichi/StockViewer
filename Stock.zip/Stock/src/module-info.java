module Stock{
	exports com.nichi.main;
	requires java.sql;
	requires com.opencsv;
	requires org.apache.poi.ooxml;
	requires org.apache.poi.poi;
	requires org.jsoup;
}