package com.nichi.main;

import java.util.Date;
import java.util.Scanner;

import com.nichi.back.utilities.DateForm;

public class StocksRunner {
	public static String numDate;
	public static void main(String[] args) {
//		Scanner sc = new Scanner(System.in);
//		System.out.println("...............Welcome to Stock data retrieval system...........");
//		System.out.println("Dear User please enter the date(DDMMYYYY): ");
		
		try {
			numDate=args[0];
		}catch(Exception e) {
			numDate = DateForm.formatDate(new Date(), "ddMMyyyy");
		}
		
		System.out.println(numDate);
		DownloadCreateInsertFetch.start();
	}
}
	