package com.nichi.main;

import java.util.Calendar;
import java.util.Date;

import com.nichi.back.create.DatabaseCreator;
import com.nichi.back.create.TableCreator;
import com.nichi.back.fetch.FetchDataFromTable;
import com.nichi.back.insert.InsertIntoBhavcopy;
import com.nichi.back.insert.InsertIntoEquity;
import com.nichi.back.insert.InsertIntoMarketCap;
import com.nichi.back.insert.InsertIntoWeekHighLow;
import com.nichi.back.utilities.DateForm;
import com.nichi.back.utilities.DownloadCSV;
import com.nichi.back.utilities.LogFile;

public class DownloadCreateInsertFetch {
	
	
	public static void start() {
		System.out.println("Initializing Logger...");
		LogFile.logSuccess("Initializing Logger...");
		LogFile.startLogger();

		System.out.println("Downloading CSV Files From NSE India...");
		LogFile.logSuccess("Downloading CSV Files From NSE India...");
		DownloadCSV.download();

		System.out.println("Creating Database...");
		LogFile.logSuccess("Creating Database...");
		DatabaseCreator.createDatabaseIfNotExists();

		System.out.println("Creating Tables...");
		LogFile.logSuccess("Creating Tables...");
		TableCreator.createAllTablesIfNotExist();

		System.out.println("Inserting Into Tables...");
		LogFile.logSuccess("Inserting Into Tables...");
		InsertIntoBhavcopy.insert();
		InsertIntoEquity.insert();
		InsertIntoWeekHighLow.insert();
		InsertIntoMarketCap.insert();

		System.out.println("Fetching Single Row From Each Tables...");
		LogFile.logSuccess("Fetching Single Row From Each Tables...");
		FetchDataFromTable.fetch();
		
	}
}
