package com.nichi.back.utilities;

public class FetchEnvironmentalVariables {
	public static String[] getVariables() {
		String usernameKey = "DB_USERNAME";
		String passwordKey = "DB_PASSWORD";
		String username = System.getenv(usernameKey);
		String password = System.getenv(passwordKey);
		System.out.println("Fetching from Environmental Variables...");
		LogFile.logSuccess("Fetching Environmental Variables...");
		if (username != null && password != null) {
			return new String[] { username, password };
		} else {
			System.out.println("Can't Find The Enviromental Variables");
			LogFile.logError("Can't Find The Enviromental Variables");
			return null;
		}
	}
}
