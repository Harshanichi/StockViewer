package com.nichi.back.utilities;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class LogFile {
	private static final Logger LOGGER = Logger.getLogger(LogFile.class.getName());

	public static void startLogger() {
		try {
			FileHandler fileHandler = new FileHandler("transaction.log", true);
			fileHandler.setFormatter(new SimpleFormatter());
			LOGGER.addHandler(fileHandler);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}



	public static void logSuccess(String message) {
		LOGGER.log(Level.INFO, message);
	}


	public static void logError(String message) {
		LOGGER.log(Level.SEVERE, message);
	
}
}
