package com.nichi.back.utilities;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnector {
	private static Connection connection = null;

	public static Connection getConnection() {
		try {
			if (connection == null || connection.isClosed()) {
				String url = Credentials.getUrl() + Credentials.getDatabaseName();
				String username = Credentials.getUsername();
				String password = Credentials.getPassword();
				connection = DriverManager.getConnection(url, username, password);
			}
		} catch (SQLException e) {
			System.out.println("Error in Connection to Database.");
			LogFile.logError("Error in Connection to Database.");
		}
		return connection;
	}
}
