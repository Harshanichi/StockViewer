package com.nichi.back.utilities;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.nichi.main.StocksRunner;

public class DateForm {
	//public static Date date = new Date();
	public static Calendar cal = Calendar.getInstance();
	
	public static Calendar dateFetch(Date date) {
		cal.setTime(date);
		cal.add(Calendar.DATE, -1);
		return cal;
	}
	public static String formatDate(Date date, String pattern) {
		LogFile.logSuccess("Changing Date Format To " + pattern);
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		return dateFormat.format(date);
	}
	
	public static Date userInputDate() {
		 
		String inputDate = StocksRunner.numDate;
		Date date = null;
 
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyyyy");
			date = dateFormat.parse(inputDate);
		} catch (ParseException e) {
			System.out.println("Invalid date format. Please enter date in ddmmyyyy format.");
		}
		return date;
	}
 
	public static Date toggleDate() {
		Date userDate = userInputDate();
		Date currentDate = new Date();
		if (userDate == null || userDate.after(currentDate)) {
			return currentDate;
		}
		return userDate;
	}
	
	
}
