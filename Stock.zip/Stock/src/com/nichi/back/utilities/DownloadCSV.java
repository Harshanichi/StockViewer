package com.nichi.back.utilities;

import java.io.FileOutputStream;  
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.jsoup.Connection;
import org.jsoup.Jsoup;

import com.nichi.main.StocksRunner;

public class DownloadCSV {
	
	public static Date currentDate = new Date();
	public static void download() {
		
		
		try {
			
//			Calendar c = DateForm.dateFetch(currentDate);
//			currentDate = c.getTime();
			//System.out.println("The date is "+DateForm.formatDate(currentDate, "ddMMyy"));
			String ddMMyyFormat = DateForm.formatDate(DateForm.userInputDate(), "ddMMyy");
			String ddMMyyyyFormat = DateForm.formatDate(DateForm.userInputDate(), "ddMMyyyy");

			String[] csvUrls = {
					"https://nsearchives.nseindia.com/content/CM_52_wk_High_low_" + ddMMyyyyFormat + ".csv",
					"https://nsearchives.nseindia.com/archives/sme/bhavcopy/sme" + ddMMyyFormat + ".csv",
					"https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv",
					"https://nsearchives.nseindia.com/web/sites/default/files/inline-files/MCAP31122023.xlsx"};
			
			for(int i=0;i<csvUrls.length;i++) {
				System.out.println(csvUrls[i]);
			}

			String[] destinationPaths = { "CM_52_wk_High_low_" + ddMMyyyyFormat + ".csv", "sme" + ddMMyyFormat + ".csv",
					"EQUITY_L.csv","MCAP31122023.xlsx" };

			for (int i = 0; i < csvUrls.length; i++) {
				try {
					downloadCsvWithJsoup(csvUrls[i], destinationPaths[i]);
					System.out.println(destinationPaths[i] + " File Downloaded Successfully.");
					LogFile.logSuccess(destinationPaths[i] + " File Downloaded Successfully.");
				} catch (IOException e) {
					System.out.println(destinationPaths[i] + " Yet Not Uploaded To NSE Website or Failed To Download.");
					LogFile.logError(destinationPaths[i] + " Yet Not Uploaded To NSE Website or Failed To Download.");
				}
			}
		} catch (Exception e) {
			LogFile.logError("Error during CSV download process " + e.getMessage());
			System.out.println("Error during CSV download process.");
			e.printStackTrace();
		}
	}

	private static void downloadCsvWithJsoup(String csvUrl, String destinationPath) throws IOException {
		try {
			Connection.Response response = Jsoup.connect(csvUrl).ignoreContentType(true).execute();

			try (InputStream in = response.bodyStream(); FileOutputStream out = new FileOutputStream(destinationPath)) {
				byte[] buffer = new byte[1024];
				int bytesRead;
				while ((bytesRead = in.read(buffer)) != -1) {
					out.write(buffer, 0, bytesRead);
				}
			}
		} catch (Exception e) {
			System.out.println("Skipping the download for URL: " + csvUrl);
			LogFile.logError("Skipping the download for URL: " + csvUrl);
			throw e;
		}
	}

//	private static String formatDate(Date date, String pattern) {
//		LogFile.logSuccess("Changing Date Format To " + pattern);
//		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
//		return dateFormat.format(date);
//	}
}
