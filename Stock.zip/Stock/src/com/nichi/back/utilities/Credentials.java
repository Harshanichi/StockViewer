package com.nichi.back.utilities;

public class Credentials {
	private static String url = "jdbc:mysql://localhost:3306/";
	private static String databaseName = "stocks_v2";
	private static String username = "root";
	private static String password = "root";
	//private static String tableNames[] = { "week_high_low", "bhavcopy", "equity" };

	public static String getUrl() {
		return url;
	}

	public static String getDatabaseName() {
		return databaseName;
	}

	public static String getUsername() {
		return username;
	}

	public static String getPassword() {
		return password;
	}

//	public static String[] getTableNames() {
//		return tableNames;
//	}
}
