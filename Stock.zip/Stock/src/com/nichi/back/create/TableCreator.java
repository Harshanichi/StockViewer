package com.nichi.back.create;

import java.sql.Connection;
import java.sql.Statement;

import com.nichi.back.utilities.Credentials;
import com.nichi.back.utilities.DatabaseConnector;
import com.nichi.back.utilities.LogFile;

public class TableCreator {

	public static void createAllTablesIfNotExist() {
		try (Connection connection = DatabaseConnector.getConnection()) {
			createWeekHighLowTable(connection, "week_high_low");
			createBhavcopyTable(connection, "bhavcopy");
			createEquityTable(connection, "equity");
			createMarketcapTable(connection, "marketcap");
		} catch (Exception e) {
			handleConnectionError(e);
		}
	}

	private static void createWeekHighLowTable(Connection connection, String tableName) {
		createTable(connection, tableName,
				"symbol VARCHAR(20) PRIMARY KEY," + "series VARCHAR(10)," + "adjusted_52_week_high DOUBLE,"
						+ "52_week_high_date DATE," + "adjusted_52_week_low DOUBLE," + "52_week_low_date DATE");
	}

	private static void createBhavcopyTable(Connection connection, String tableName) {
		createTable(connection, tableName,
				"symbol VARCHAR(20)," + "MARKET VARCHAR(10)," + "SERIES VARCHAR(10)," + "SECURITY VARCHAR(255),"
						+ "PREV_CL_PR DOUBLE," + "OPEN_PRICE DOUBLE," + "HIGH_PRICE DOUBLE," + "LOW_PRICE DOUBLE,"
						+ "CLOSE_PRICE DOUBLE," + "NET_TRDVAL DOUBLE," + "NET_TRDQTY INT," + "CORP_IND VARCHAR(10),"
						+ "HI_52_WK DOUBLE," + "LO_52_WK DOUBLE," + "insertion_date DATE,"
						+ "PRIMARY KEY (symbol, insertion_date)");
	}

	private static void createEquityTable(Connection connection, String tableName) {
		createTable(connection, tableName,
				"SYMBOL VARCHAR(255)," + "NAME_OF_COMPANY VARCHAR(255)," + "SERIES VARCHAR(255),"
						+ "DATE_OF_LISTING DATE," + "PAID_UP_VALUE DOUBLE," + "MARKET_LOT INT,"
						+ "ISIN_NUMBER VARCHAR(255) PRIMARY KEY," + "FACE_VALUE DOUBLE");
	}
	
	
	private static void createMarketcapTable(Connection connection, String tableName) {
		createTable(connection, tableName,
				"SrNo INT," + "SYMBOL VARCHAR(255) NOT NULL," + "COMPANY_NAME VARCHAR(255),"
						+ "Market_Capitalization VARCHAR(255) NOT NULL," + "PRIMARY KEY(SYMBOL)");
	}

	private static void createTable(Connection connection, String tableName, String columns) {
		try (Statement statement = connection.createStatement()) {
			String createTableQuery = "CREATE TABLE IF NOT EXISTS " + tableName + " (" + columns + ")";
			statement.executeUpdate(createTableQuery);

			System.out.println("Table '" + tableName + "' created successfully.");
			LogFile.logSuccess("Table '" + tableName + "' created successfully.");

		} catch (Exception e) {
			handleTableCreationError(tableName);
			LogFile.logError("Proceeding with other tasks, table '" + tableName + "' may not be available.");
		}
	}

//	private static void createTableIfNotExists(Connection connection, String tableName) {
//		try {
//			switch (tableName) {
//			case "week_high_low":
//				createWeekHighLowTable(connection, tableName);
//				break;
//			case "bhavcopy":
//				createBhavcopyTable(connection, tableName);
//				break;
//			case "equity":
//				createEquityTable(connection, tableName);
//				break;
//			default:
//				handleTableCreationError(tableName);
//				break;
//			}
//		} catch (Exception e) {
//			LogFile.logError("Failed to create table '" + tableName + "'.");
//		}
//	}

	private static void handleTableCreationError(String tableName) {
		System.out.println("Failed to create table: " + tableName);
		LogFile.logError("Failed to create table: " + tableName);
	}

	private static void handleConnectionError(Exception e) {
		System.out.println("Error connecting to the database:");
		e.printStackTrace();
		LogFile.logError("Error connecting to the database at " + new java.util.Date());
	}
}
