package com.nichi.back.create;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.nichi.back.utilities.Credentials;
import com.nichi.back.utilities.LogFile;

public class DatabaseCreator {

	private static String databaseName = Credentials.getDatabaseName();

	public static void createDatabaseIfNotExists() {
		try (Connection connection = getConnection()) {
			Statement statement = connection.createStatement();
			String createDatabaseQuery = "CREATE DATABASE IF NOT EXISTS " + databaseName;
			statement.executeUpdate(createDatabaseQuery);
			System.out.println("Database '" + databaseName + "' created successfully.");
			LogFile.logSuccess("Database '" + databaseName + "' created successfully at " + new java.util.Date());
		} catch (SQLException sqlException) {
			handleSQLException(sqlException);
		} 
	}

	private static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(Credentials.getUrl(), Credentials.getUsername(), Credentials.getPassword());
	}

	private static void handleSQLException(SQLException e) {
		System.out.println("Error occurred while creating the database:");
		e.printStackTrace();
		LogFile.logError("SQLException occurred during database creation at " + new java.util.Date());
	}
}
