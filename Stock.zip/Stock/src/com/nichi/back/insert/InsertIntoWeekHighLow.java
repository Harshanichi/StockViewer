package com.nichi.back.insert;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.nichi.back.utilities.Credentials;
import com.nichi.back.utilities.DatabaseConnector;
import com.nichi.back.utilities.DateForm;
import com.nichi.back.utilities.LogFile;
import com.opencsv.CSVReader;

public class InsertIntoWeekHighLow {
	private static Connection connection = null;
	private static String tableName = "week_high_low";

	public static Connection insert() {
//		Date currentDate = new Date();
//		String ddMMyyyyFormat = DateForm.formatDate(currentDate, "ddMMyyyy");
		try {			
			connection = DatabaseConnector.getConnection();
			int initialRowCount = getRowCount();
			if (initialRowCount == -1) {
				return connection;
			}
			LogFile.logSuccess("Inserting Into " + tableName + "...");
			System.out.println("Inserting Into " + tableName + "...");
			System.out.println("This is from insert function of week low trying to insert for date "+DateForm.formatDate(DateForm.userInputDate(), "ddMMyyyy"));
			insertDataFromCSV("CM_52_wk_High_low_" + DateForm.formatDate(DateForm.userInputDate(), "ddMMyyyy") + ".csv");
			int finalRowCount = getRowCount();

			int rowsInsertedCount = finalRowCount - initialRowCount;
			int alreadyPresentCount = Math.max(initialRowCount - rowsInsertedCount, 0);

			System.out.println("Rows inserted: " + rowsInsertedCount);
			LogFile.logSuccess("Rows inserted: " + rowsInsertedCount);
			System.out.println("Already present rows: " + alreadyPresentCount);
			LogFile.logSuccess("Already present rows: " + alreadyPresentCount);
		} catch (Exception e) {
			LogFile.logError("Error In Inserting Data into " + tableName);
			e.printStackTrace();
		}
		return connection;
	}

	private static java.sql.Date convertToDate(String inputDate) throws ParseException {
		if ("-".equals(inputDate)) {
			return null;
		}
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date parsedDate = inputDateFormat.parse(inputDate);
		return new java.sql.Date(parsedDate.getTime());
	}

	private static void insertDataFromCSV(String csvFilePath) {
		try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath));
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + tableName
						+ " (symbol, series, adjusted_52_week_high, 52_week_high_date, adjusted_52_week_low, 52_week_low_date) "
						+ "VALUES (?, ?, ?, ?, ?, ?) " + "ON DUPLICATE KEY UPDATE "
						+ "adjusted_52_week_high = VALUES(adjusted_52_week_high), "
						+ "52_week_high_date = VALUES(52_week_high_date), "
						+ "adjusted_52_week_low = VALUES(adjusted_52_week_low), "
						+ "52_week_low_date = VALUES(52_week_low_date)")) {

			csvReader.readNext(); // Skip first line
			csvReader.readNext(); // Skip second line

			String[] header = csvReader.readNext();

			try {
				String[] nextLine;
				while ((nextLine = csvReader.readNext()) != null) {
					preparedStatement.setString(1, nextLine[0]);
					preparedStatement.setString(2, nextLine[1]);

					if ("-".equals(nextLine[2])) {
						preparedStatement.setNull(3, java.sql.Types.DOUBLE);
					} else {
						preparedStatement.setDouble(3, Double.parseDouble(nextLine[2])); // adjusted_52_week_high
					}

					preparedStatement.setDate(4, convertToDate(nextLine[3]));

					if ("-".equals(nextLine[4])) {
						preparedStatement.setNull(5, java.sql.Types.DOUBLE);
					} else {
						preparedStatement.setDouble(5, Double.parseDouble(nextLine[4])); // adjusted_52_week_low
					}

					preparedStatement.setDate(6, convertToDate(nextLine[5]));
					preparedStatement.executeUpdate();
				}
			} catch (SQLException e) {
				LogFile.logError("SQLException " + tableName);
			}
		} catch (Exception e) {
			System.out.println(
					"Error reading CSV file: " + e.getMessage() + "\nFailed To Insert Into Table " + tableName);
			LogFile.logError("Error reading CSV file: " + e.getMessage());
		}
	}
	
	private static int getRowCount() {
		try (PreparedStatement countStatement = connection.prepareStatement("SELECT COUNT(*) FROM " + tableName);
				ResultSet resultSet = countStatement.executeQuery()) {
			resultSet.next();
			return resultSet.getInt(1);
		} catch (SQLException e) {
			handleException("Error getting row count", e);
			return -1;
		}
	}
	
	private static void handleException(String message, Exception e) {
		System.out.println(message);
		LogFile.logError(message + ": " + e.getMessage());
		e.printStackTrace();
	}

//	private static String formatDate(Date date, String pattern) {
//		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
//		return dateFormat.format(date);
//	}
}
