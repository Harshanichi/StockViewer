package com.nichi.back.insert;

import java.io.FileReader; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.nichi.back.utilities.Credentials;
import com.nichi.back.utilities.DatabaseConnector;
import com.nichi.back.utilities.DateForm;
import com.nichi.back.utilities.DownloadCSV;
import com.nichi.back.utilities.LogFile;
import com.opencsv.CSVReader;

public class InsertIntoBhavcopy {
	private static Connection connection = null;
	private static String tableName = "bhavcopy";

	public static Connection insert() {
		try {
			connection = DatabaseConnector.getConnection();
			int initialRowCount = getRowCount();
			if (initialRowCount == -1) {
				return connection;
			}
			LogFile.logSuccess("Inserting Into " + tableName + "...");
			System.out.println("Inserting Into " + tableName + "...");
			
			System.out.println("This date is coming from insert function "+DateForm.formatDate(DateForm.userInputDate(), "ddMMyy"));
			insertDataFromCSV("sme" + DateForm.formatDate(DateForm.userInputDate(), "ddMMyy") + ".csv");

			int finalRowCount = getRowCount();

			int rowsInsertedCount = finalRowCount - initialRowCount;
			int alreadyPresentCount = Math.max(initialRowCount - rowsInsertedCount, 0);

			System.out.println("Rows inserted: " + rowsInsertedCount);
			LogFile.logSuccess("Rows inserted: " + rowsInsertedCount);
			System.out.println("Already present rows: " + alreadyPresentCount);
			LogFile.logSuccess("Already present rows: " + alreadyPresentCount);
		} catch (Exception e) {
			LogFile.logError("Error In Inserting Data into " + tableName);
		}
		return connection;
	}

	private static void insertDataFromCSV(String csvFilePath) {
		try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath))) {
			csvReader.readNext(); 
			String insertQuery = "INSERT INTO " + tableName
					+ " (MARKET, SERIES, SYMBOL, SECURITY, PREV_CL_PR, OPEN_PRICE, HIGH_PRICE, LOW_PRICE, CLOSE_PRICE, NET_TRDVAL, NET_TRDQTY, CORP_IND, HI_52_WK, LO_52_WK, INSERTION_DATE) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
				String[] nextLine;
				while ((nextLine = csvReader.readNext()) != null) {
					setPreparedStatementValues(preparedStatement, nextLine);
					preparedStatement.setDate(15, new java.sql.Date(DateForm.userInputDate().getTime()));
					preparedStatement.executeUpdate();
				}
			} catch (SQLException e) {
//				handleException("Some Rows Are Already Present ", e);
			}
		} catch (Exception e) {
			System.out.println(
					"Error reading CSV file: " + e.getMessage() + "\nFailed To Insert Into Table " + tableName);
			LogFile.logError("Error reading CSV file: " + e.getMessage());
			handleException("Error reading CSV file", e);
		}
	}

	private static void setPreparedStatementValues(PreparedStatement preparedStatement, String[] values)
			throws SQLException {
		preparedStatement.setString(1, values[0]);
		preparedStatement.setString(2, values[1]);
		preparedStatement.setString(3, values[2]);
		preparedStatement.setString(4, values[3]);
		preparedStatement.setDouble(5, Double.parseDouble(values[4]));
		preparedStatement.setDouble(6, Double.parseDouble(values[5]));
		preparedStatement.setDouble(7, Double.parseDouble(values[6]));
		preparedStatement.setDouble(8, Double.parseDouble(values[7]));
		preparedStatement.setDouble(9, Double.parseDouble(values[8]));
		preparedStatement.setDouble(10, Double.parseDouble(values[9]));
		preparedStatement.setInt(11, Integer.parseInt(values[10]));
		preparedStatement.setString(12, values[11]);
		preparedStatement.setDouble(13, Double.parseDouble(values[12]));
		preparedStatement.setDouble(14, Double.parseDouble(values[13]));
	}

//	private static String formatDate(Date date, String pattern) {
//		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
//		return dateFormat.format(date);
//	}

	private static int getRowCount() {
		try (PreparedStatement countStatement = connection.prepareStatement("SELECT COUNT(*) FROM " + tableName);
				ResultSet resultSet = countStatement.executeQuery()) {
			resultSet.next();
			return resultSet.getInt(1);
		} catch (SQLException e) {
			handleException("Error getting row count", e);
			return -1;
		}
	}

	private static void handleException(String message, Exception e) {
		System.out.println(message);
		LogFile.logError(message + ": " + e.getMessage());
	}
}
