package com.nichi.back.insert;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.nichi.back.utilities.Credentials;
import com.nichi.back.utilities.DatabaseConnector;
import com.nichi.back.utilities.LogFile;
import com.opencsv.CSVReader;

public class InsertIntoEquity {
	private static Connection connection = null;
	private static String tableName = "equity";

	public static Connection insert() {
		try {

			connection = DatabaseConnector.getConnection();
			int initialRowCount = getRowCount();
			if (initialRowCount == -1) {
				return connection;
			}
			LogFile.logSuccess("Inserting Into " + tableName + "...");
			System.out.println("Inserting Into " + tableName + "...");
			insertDataFromCSV("EQUITY_L.csv");
			int finalRowCount = getRowCount();

			int rowsInsertedCount = finalRowCount - initialRowCount;
			int alreadyPresentCount = Math.max(initialRowCount - rowsInsertedCount, 0);

			System.out.println("Rows inserted: " + rowsInsertedCount);
			LogFile.logSuccess("Rows inserted: " + rowsInsertedCount);
			System.out.println("Already present rows: " + alreadyPresentCount);
			LogFile.logSuccess("Already present rows: " + alreadyPresentCount);
		} catch (Exception e) {
			LogFile.logError("Error In Inserting Data into " + tableName);
		}
		return connection;
	}

	private static void handleException(String message, Exception e) {
		System.out.println(message);
		LogFile.logError(message + ": " + e.getMessage());
		e.printStackTrace();
	}

	private static java.sql.Date convertToDate(String inputDate) throws ParseException {
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Date parsedDate = inputDateFormat.parse(inputDate);
		return new java.sql.Date(parsedDate.getTime());
	}

	private static void insertDataFromCSV(String csvFilePath) {
		try (CSVReader csvReader = new CSVReader(new FileReader(csvFilePath));
				PreparedStatement preparedStatement = connection.prepareStatement(
						"INSERT IGNORE INTO " + tableName + " (SYMBOL, NAME_OF_COMPANY, SERIES, DATE_OF_LISTING, "
								+ "PAID_UP_VALUE, MARKET_LOT, ISIN_NUMBER, FACE_VALUE) "
								+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?) " + "ON DUPLICATE KEY UPDATE "
								+ "SYMBOL = VALUES(SYMBOL), " + "NAME_OF_COMPANY = VALUES(NAME_OF_COMPANY), "
								+ "SERIES = VALUES(SERIES), " + "DATE_OF_LISTING = VALUES(DATE_OF_LISTING), "
								+ "PAID_UP_VALUE = VALUES(PAID_UP_VALUE), " + "MARKET_LOT = VALUES(MARKET_LOT), "
								+ "ISIN_NUMBER = VALUES(ISIN_NUMBER), " + "FACE_VALUE = VALUES(FACE_VALUE)")) {

			// Skip the first line
			csvReader.readNext();
			String[] nextLine;
			while ((nextLine = csvReader.readNext()) != null) {
				try {
					setPreparedStatementValues(preparedStatement, nextLine);

					preparedStatement.executeUpdate();

				} catch (SQLException | ParseException e) {
					System.out.println(
							"Error reading CSV file: " + e.getMessage() + "\nFailed To Insert Into Table " + tableName);
					LogFile.logError("Error reading CSV file: " + e.getMessage());
					handleException("Error reading CSV file", e);
					handleException("Error reading CSV file", e);
				}
			}

		} catch (Exception e) {
			handleException("Error during CSV processing", e);
		}
	}

	private static int getRowCount() {
		try (PreparedStatement countStatement = connection.prepareStatement("SELECT COUNT(*) FROM " + tableName);
				ResultSet resultSet = countStatement.executeQuery()) {
			resultSet.next();
			return resultSet.getInt(1);
		} catch (SQLException e) {
			handleException("Error getting row count", e);
			return -1;
		}
	}

	private static void setPreparedStatementValues(PreparedStatement preparedStatement, String[] data)
			throws SQLException, ParseException {
		preparedStatement.setString(1, data[0]);
		preparedStatement.setString(2, data[1]);
		preparedStatement.setString(3, data[2]);
		preparedStatement.setDate(4, convertToDate(data[3]));
		preparedStatement.setDouble(5, Double.parseDouble(data[4]));
		preparedStatement.setInt(6, Integer.parseInt(data[5]));
		preparedStatement.setString(7, data[6]);
		preparedStatement.setDouble(8, Double.parseDouble(data[7]));
	}
}
