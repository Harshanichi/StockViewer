package com.nichi.back.insert;


import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.nichi.back.utilities.DatabaseConnector;
import com.nichi.back.utilities.LogFile;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class InsertIntoMarketCap {

    private static Connection connection = null;
    private static String tableName = "marketcap";

    public static Connection insert() {
        try {
            connection = DatabaseConnector.getConnection();
            int initialRowCount = getRowCount();
            if (initialRowCount == -1) {
                return connection;
            }
            LogFile.logSuccess("Inserting Into " + tableName + "...");
            System.out.println("Inserting Into " + tableName + "...");
            insertDataFromExcel("MCAP31122023.xlsx");
            int finalRowCount = getRowCount();

            int rowsInsertedCount = finalRowCount - initialRowCount;
            int alreadyPresentCount = Math.max(initialRowCount - rowsInsertedCount, 0);

            System.out.println("Rows inserted: " + rowsInsertedCount);
            LogFile.logSuccess("Rows inserted: " + rowsInsertedCount);
            System.out.println("Already present rows: " + alreadyPresentCount);
            LogFile.logSuccess("Already present rows: " + alreadyPresentCount);
        } catch (Exception e) {
            LogFile.logError("Error In Inserting Data into " + tableName);
            e.printStackTrace();
        }
        return connection;
    }

    private static void insertDataFromExcel(String excelFilePath) {
        try (FileInputStream fis = new FileInputStream(excelFilePath);
                Workbook workbook = new XSSFWorkbook(fis);
                PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + tableName
                        + " (SrNo, SYMBOL, COMPANY_NAME, Market_Capitalization) "
                        + "VALUES (?, ?, ?, ?) " + "ON DUPLICATE KEY UPDATE "
                        + "SYMBOL = VALUES(SYMBOL), "
                        + "COMPANY_NAME = VALUES(COMPANY_NAME), "
                        + "Market_Capitalization = VALUES(Market_Capitalization)")) {

            Sheet sheet = workbook.getSheetAt(0); // Assuming data is in the first sheet

            
            for (int i = 1; i < sheet.getLastRowNum()-1; i++) { // Start from the second row
                Row row = sheet.getRow(i);
                if (row != null) {
                    Cell cell0 = row.getCell(0);
                    Cell cell1 = row.getCell(1);
                    Cell cell2 = row.getCell(2);
                    Cell cell3 = row.getCell(3);

                    // Check cell types before reading their values
                    String cell0Value = cell0.getCellType() == CellType.NUMERIC ? String.valueOf((int) cell0.getNumericCellValue()) : "";
                    String cell1Value = cell1.getCellType() == CellType.STRING ? cell1.getStringCellValue() : "";
                    String cell2Value = cell2.getCellType() == CellType.STRING ? cell2.getStringCellValue() : "";
                    
                    String cell3Value = "";
                    if (cell3 != null) {
                        if (cell3.getCellType() == CellType.STRING) {
                            cell3Value = cell3.getStringCellValue();
                        } else if (cell3.getCellType() == CellType.NUMERIC) {
                            cell3Value = String.valueOf((int) cell3.getNumericCellValue());
                        }
                    }

                    preparedStatement.setString(1, cell0Value);
                    preparedStatement.setString(2, cell1Value);
                    preparedStatement.setString(3, cell2Value);
                    preparedStatement.setString(4, cell3Value);

                    preparedStatement.executeUpdate();
                }
            }
            
        } catch (Exception e) {
            System.out.println("Error reading Excel file: " + e.getMessage());
            LogFile.logError("Error reading Excel file: " + e.getMessage());
        }
    }

    private static int getRowCount() {
        try (PreparedStatement countStatement = connection
                .prepareStatement("SELECT COUNT(*) FROM " + tableName);
                ResultSet resultSet = countStatement.executeQuery()) {
            resultSet.next();
            return resultSet.getInt(1);
        } catch (SQLException e) {
            handleException("Error getting row count", e);
            return -1;
        }
    }

    private static void handleException(String message, Exception e) {
        System.out.println(message);
        LogFile.logError(message + ": " + e.getMessage());
        e.printStackTrace();
    }
}