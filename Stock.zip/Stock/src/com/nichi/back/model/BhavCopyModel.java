package com.nichi.back.model;

public class BhavCopyModel {

	private String market;
	private String series;
	private String symbol;
	private String security;
	private Double prevClosePrice;
	private Double openPrice;
	private Double highPrice;
	private Double lowPrice;
	private Double closePrice;
	private Double netTradeValue;
	private int netTradeQuantity;
	private String corpInd;
	private Double high52Week;
	private Double low52Week;

	public BhavCopyModel() {
	}

	public BhavCopyModel(String market, String series, String symbol, String security, Double prevClosePrice,
			Double openPrice, Double highPrice, Double lowPrice, Double closePrice, Double netTradeValue,
			int netTradeQuantity, String corpInd, Double high52Week, Double low52Week) {
		this.market = market;
		this.series = series;
		this.symbol = symbol;
		this.security = security;
		this.prevClosePrice = prevClosePrice;
		this.openPrice = openPrice;
		this.highPrice = highPrice;
		this.lowPrice = lowPrice;
		this.closePrice = closePrice;
		this.netTradeValue = netTradeValue;
		this.netTradeQuantity = netTradeQuantity;
		this.corpInd = corpInd;
		this.high52Week = high52Week;
		this.low52Week = low52Week;
	}

	public String getMarket() {
		return market;
	}

	public void setMarket(String market) {
		this.market = market;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getSecurity() {
		return security;
	}

	public void setSecurity(String security) {
		this.security = security;
	}

	public Double getPrevClosePrice() {
		return prevClosePrice;
	}

	public void setPrevClosePrice(Double prevClosePrice) {
		this.prevClosePrice = prevClosePrice;
	}

	public Double getOpenPrice() {
		return openPrice;
	}

	public void setOpenPrice(Double openPrice) {
		this.openPrice = openPrice;
	}

	public Double getHighPrice() {
		return highPrice;
	}

	public void setHighPrice(Double highPrice) {
		this.highPrice = highPrice;
	}

	public Double getLowPrice() {
		return lowPrice;
	}

	public void setLowPrice(Double lowPrice) {
		this.lowPrice = lowPrice;
	}

	public Double getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(Double closePrice) {
		this.closePrice = closePrice;
	}

	public Double getNetTradeValue() {
		return netTradeValue;
	}

	public void setNetTradeValue(Double netTradeValue) {
		this.netTradeValue = netTradeValue;
	}

	public int getNetTradeQuantity() {
		return netTradeQuantity;
	}

	public void setNetTradeQuantity(int netTradeQuantity) {
		this.netTradeQuantity = netTradeQuantity;
	}

	public String getCorpInd() {
		return corpInd;
	}

	public void setCorpInd(String corpInd) {
		this.corpInd = corpInd;
	}

	public Double getHigh52Week() {
		return high52Week;
	}

	public void setHigh52Week(Double high52Week) {
		this.high52Week = high52Week;
	}

	public Double getLow52Week() {
		return low52Week;
	}

	public void setLow52Week(Double low52Week) {
		this.low52Week = low52Week;
	}

	public String toString() {
		return "BhavCopyModel [market=" + market + ", series=" + series + ", symbol=" + symbol + ", security="
				+ security + ", prevClosePrice=" + prevClosePrice + ", openPrice=" + openPrice + ", highPrice="
				+ highPrice + ", lowPrice=" + lowPrice + ", closePrice=" + closePrice + ", netTradeValue="
				+ netTradeValue + ", netTradeQuantity=" + netTradeQuantity + ", corpInd=" + corpInd + ", high52Week="
				+ high52Week + ", low52Week=" + low52Week + "]";
	}

}
