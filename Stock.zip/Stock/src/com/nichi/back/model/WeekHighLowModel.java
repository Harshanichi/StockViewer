package com.nichi.back.model;

import java.util.Date;

public class WeekHighLowModel {

	private String symbol;
	private String series;
	private Double adjusted52WeekHigh;
	private Date weekHighDate;
	private Double adjusted52WeekLow;
	private Date weekLowDate;

	public WeekHighLowModel() {
	}

	public WeekHighLowModel(String symbol, String series, Double adjusted52WeekHigh, Date weekHighDate,
			Double adjusted52WeekLow, Date weekLowDate) {
		this.symbol = symbol;
		this.series = series;
		this.adjusted52WeekHigh = adjusted52WeekHigh;
		this.weekHighDate = weekHighDate;
		this.adjusted52WeekLow = adjusted52WeekLow;
		this.weekLowDate = weekLowDate;
	}

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public Double getAdjusted52WeekHigh() {
		return adjusted52WeekHigh;
	}

	public void setAdjusted52WeekHigh(Double adjusted52WeekHigh) {
		this.adjusted52WeekHigh = adjusted52WeekHigh;
	}

	public Date getWeekHighDate() {
		return weekHighDate;
	}

	public void setWeekHighDate(Date weekHighDate) {
		this.weekHighDate = weekHighDate;
	}

	public Double getAdjusted52WeekLow() {
		return adjusted52WeekLow;
	}

	public void setAdjusted52WeekLow(Double adjusted52WeekLow) {
		this.adjusted52WeekLow = adjusted52WeekLow;
	}

	public Date getWeekLowDate() {
		return weekLowDate;
	}

	public void setWeekLowDate(Date weekLowDate) {
		this.weekLowDate = weekLowDate;
	}

	public String toString() {
		return "WeekHighLowModel [symbol=" + symbol + ", series=" + series + ", adjusted52WeekHigh="
				+ adjusted52WeekHigh + ", weekHighDate=" + weekHighDate + ", adjusted52WeekLow=" + adjusted52WeekLow
				+ ", weekLowDate=" + weekLowDate + "]";
	}

}
