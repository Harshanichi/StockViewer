package com.nichi.back.model;

import java.util.Date;

public class EquityModel {

	private String symbol;
	private String nameOfCompany;
	private String series;
	private Date dateOfListing;
	private Double paidUpValue;
	private int marketLot;
	private String isinNumber;
	private Double faceValue;

	public EquityModel() {
	}

	public EquityModel(String symbol, String nameOfCompany, String series, Date dateOfListing, Double paidUpValue,
			int marketLot, String isinNumber, Double faceValue) {
		this.symbol = symbol;
		this.nameOfCompany = nameOfCompany;
		this.series = series;
		this.dateOfListing = dateOfListing;
		this.paidUpValue = paidUpValue;
		this.marketLot = marketLot;
		this.isinNumber = isinNumber;
		this.faceValue = faceValue;
	}

	// Getters and Setters

	public String getSymbol() {
		return symbol;
	}

	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}

	public String getNameOfCompany() {
		return nameOfCompany;
	}

	public void setNameOfCompany(String nameOfCompany) {
		this.nameOfCompany = nameOfCompany;
	}

	public String getSeries() {
		return series;
	}

	public void setSeries(String series) {
		this.series = series;
	}

	public Date getDateOfListing() {
		return dateOfListing;
	}

	public void setDateOfListing(Date dateOfListing) {
		this.dateOfListing = dateOfListing;
	}

	public Double getPaidUpValue() {
		return paidUpValue;
	}

	public void setPaidUpValue(Double paidUpValue) {
		this.paidUpValue = paidUpValue;
	}

	public int getMarketLot() {
		return marketLot;
	}

	public void setMarketLot(int marketLot) {
		this.marketLot = marketLot;
	}

	public String getIsinNumber() {
		return isinNumber;
	}

	public void setIsinNumber(String isinNumber) {
		this.isinNumber = isinNumber;
	}

	public Double getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(Double faceValue) {
		this.faceValue = faceValue;
	}

	public String toString() {
		return "EquityModel [symbol=" + symbol + ", nameOfCompany=" + nameOfCompany + ", series=" + series
				+ ", dateOfListing=" + dateOfListing + ", paidUpValue=" + paidUpValue + ", marketLot=" + marketLot
				+ ", isinNumber=" + isinNumber + ", faceValue=" + faceValue + "]";
	}

}
