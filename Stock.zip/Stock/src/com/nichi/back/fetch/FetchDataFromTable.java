package com.nichi.back.fetch;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.nichi.back.model.BhavCopyModel;
import com.nichi.back.model.EquityModel;
import com.nichi.back.model.WeekHighLowModel;
import com.nichi.back.utilities.Credentials;
import com.nichi.back.utilities.DatabaseConnector;
import com.nichi.back.utilities.LogFile;

public class FetchDataFromTable {

	private static Connection connection = null;
	private static String[] tableNames = {"week_high_low", "bhavcopy", "equity"};

	public static Connection fetch() {
		connection = DatabaseConnector.getConnection();
		for (String tableName : tableNames) {
			fetchAndDisplaySingleRow(tableName);
		}
		return connection;
	}

	private static void fetchAndDisplaySingleRow(String tableName) {
		try (Statement statement = connection.createStatement()) {
			LogFile.logSuccess("Fetching from Table " + tableName);

			String fetchQuery = "SELECT * FROM " + tableName + " LIMIT 1";
			ResultSet resultSet = statement.executeQuery(fetchQuery);

			switch (tableName) {
			case "week_high_low":
				handleWeekHighLowFetch(resultSet);
				break;
			case "bhavcopy":
				handleBhavCopyFetch(resultSet);
				break;
			case "equity":
				handleEquityFetch(resultSet);
				break;
			default:
				handleFetchError(new SQLException("Invalid table name: " + tableName));
			}
		} catch (SQLException e) {
			handleFetchError(e);
		}
	}

	private static void handleWeekHighLowFetch(ResultSet resultSet) throws SQLException {
		if (resultSet.next()) {
			WeekHighLowModel stockData = new WeekHighLowModel(resultSet.getString("symbol"),
					resultSet.getString("series"), resultSet.getDouble("adjusted_52_week_high"),
					resultSet.getDate("52_week_high_date"), resultSet.getDouble("adjusted_52_week_low"),
					resultSet.getDate("52_week_low_date"));
			printAndLogFetchedData(stockData);
		}
	}

	private static void handleBhavCopyFetch(ResultSet resultSet) throws SQLException {
		if (resultSet.next()) {
			BhavCopyModel bhavCopyData = new BhavCopyModel(resultSet.getString("MARKET"), resultSet.getString("SERIES"),
					resultSet.getString("SYMBOL"), resultSet.getString("SECURITY"), resultSet.getDouble("PREV_CL_PR"),
					resultSet.getDouble("OPEN_PRICE"), resultSet.getDouble("HIGH_PRICE"),
					resultSet.getDouble("LOW_PRICE"), resultSet.getDouble("CLOSE_PRICE"),
					resultSet.getDouble("NET_TRDVAL"), resultSet.getInt("NET_TRDQTY"), resultSet.getString("CORP_IND"),
					resultSet.getDouble("HI_52_WK"), resultSet.getDouble("LO_52_WK"));
			printAndLogFetchedData(bhavCopyData);
		}
	}

	private static void handleEquityFetch(ResultSet resultSet) throws SQLException {
		if (resultSet.next()) {
			EquityModel equityData = new EquityModel(resultSet.getString("SYMBOL"),
					resultSet.getString("NAME_OF_COMPANY"), resultSet.getString("SERIES"),
					resultSet.getDate("DATE_OF_LISTING"), resultSet.getDouble("PAID_UP_VALUE"),
					resultSet.getInt("MARKET_LOT"), resultSet.getString("ISIN_NUMBER"),
					resultSet.getDouble("FACE_VALUE"));
			printAndLogFetchedData(equityData);
		}
	}

	private static void printAndLogFetchedData(Object data) {
		System.out.println(data);
		LogFile.logSuccess("Fetched Data " + data);
	}

	private static void handleFetchError(SQLException e) {
		System.out.println("Error in fetching data:");
		e.printStackTrace();
		LogFile.logError("Error in fetching data at " + new java.util.Date());
	}
}
